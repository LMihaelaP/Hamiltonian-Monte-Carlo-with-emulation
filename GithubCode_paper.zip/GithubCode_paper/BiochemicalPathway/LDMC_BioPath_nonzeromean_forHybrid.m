function [current_p,LogPosterior_sim,LogPosterior_em,GradLogPost_em,...
    GradGradLogPost_em, GradGradGradLogPost_em, ObjFct_sim, noODE_counter, posdef] = ...
    LDMC_BioPath_nonzeromean_forHybrid(current_p, sigma2, StepSize, L, ...
    gp_regr, x_regr, y_regr, nd, phase_ind, trueData, time, tspan, ...
    alp, bet, sc, extra_p, ......
    LogPosterior_sim_begin, LogPosterior_em_begin, GradLogPost_em_begin, ...
    GradGradLogPost_em_begin, GradGradGradLogPost_em_begin, ObjFct_sim_begin, ...
    do_nuts, invLref, do_DA, H, B, b)

% Runs an iteration of the Lagrangian dynamical Monte Carlo

noODE_counter = 0; % count the no of ODE evaluations

p = current_p'; % position

% Obtain LogPost, GradLogPost, GradGradLogPost and GradGradGradLogPost
% at the beginning of the trajectory
% It may not be the same one as that saved at the previous iteration for
% the accepted point since the noise variance, if sampled in a Gibbs step
% will lead to a different LogLik

if phase_ind == 2
    
    em_ind = 1; % use emulator
    grad1_SimInd = NaN; grad23_EmInd = [1 1];
    [LogPosterior_em_begin,GradLogPost_em_begin,GradGradLogPost_em_begin,...
        GradGradGradLogPost_em_begin, ~, ~, FirstSecondGradProd_em_begin] = ...
        HMCDerivPosterior_all_BioPath_nonzeromean(p', ...
        sigma2, trueData, time, tspan, alp, bet, nd, sc, extra_p, ...
        em_ind, phase_ind, grad1_SimInd, grad23_EmInd, ...
        gp_regr, x_regr, y_regr, do_nuts, invLref, H, B, b);
    
    n = size(trueData,1);
    
    LogPosterior_sim_begin = sum ( -n/2.*log(sigma2)-n/2*log(2*pi)*size(sigma2,1) - ...
        ObjFct_sim_begin./(2.*sigma2) ) + Prior_Log_GradLog(p', alp, bet, do_nuts);
    
    
end

% Get G
lambda = 0.0;

G_current = (1-lambda) .* (-GradGradLogPost_em_begin) + lambda .* (GradLogPost_em_begin*GradLogPost_em_begin');

[~,posdef] = chol(G_current);

while (posdef ~= 0) && (lambda < 0.99) && (LogPosterior_em_begin ~= -10^10) % < 1 strangel reachs 1.1
    lambda = lambda + 0.1;
    G_current = (1-lambda) .* (-GradGradLogPost_em_begin) + lambda .* (GradLogPost_em_begin*GradLogPost_em_begin');
    [~,posdef] = chol(G_current);
end

G = G_current;

G = G + (1e-06)*eye(nd,nd);

[~,posdef] = chol(G);

if cond(G)>1e+15 % high condition number
    posdef = 1; % posdef from chol can still be 0,
    % but I get warnings that matrix is close to singular or
    % badly scaled when inverting it
end

if posdef ~= 0
    LogPosterior_em = LogPosterior_em_begin;
    GradLogPost_em = GradLogPost_em_begin;
    GradGradLogPost_em = GradGradLogPost_em_begin;
    GradGradGradLogPost_em = GradGradGradLogPost_em_begin;
    LogPosterior_sim = LogPosterior_sim_begin;
    ObjFct_sim = ObjFct_sim_begin;
    current_p = current_p;
    
    return
    
else
    
    InvG = inv(G);
    
    OriginalCholInvG = chol(InvG);
    
    OriginalG     = G;
    
    % Get the partial derivatives dG/dphi
    GDeriv = NaN(repmat(nd,1,3));
    for d = 1:nd
        GDeriv(:,:,d) = (1-lambda) .* (-GradGradGradLogPost_em_begin{d}) + lambda .* FirstSecondGradProd_em_begin{d};
    end
    
    Gamma1 = 0.5*(permute(GDeriv,[1,3,2]) + permute(GDeriv,[3,2,1]) - GDeriv);
    
    % propose velocity
    ProposedVelocity = (randn(1,nd)*OriginalCholInvG)';
    OriginalVelocity = ProposedVelocity;
    
    CurrentLJL = LogPosterior_em_begin;
    
    % Calculate current H value
    CurrentLogDet = 0.5*( nd*log(2) + nd*log(pi) + 2*sum(log(diag(OriginalCholInvG))) );
    %[sum(log(diag(OriginalCholInvG))), -sum(log(diag(OriginalCholG)))] %
    %they're equivalent
    
    CurrentH  = -CurrentLJL + CurrentLogDet + (OriginalVelocity'*OriginalG*OriginalVelocity)/2;
    
    % Accumulate determinant to be adjusted in acceptance rate
    Deltalogdet = 0;
    
    % Calculate the partial derivatives dG/dq
    TraceInvGdG = NaN(1,nd);
    
    for d = 1:nd
        TraceInvGdG(d) = sum(sum(InvG.*GDeriv(:,:,d)'));
        %or TraceInvGdG(d) = trace(G\GDeriv(:,:,d)); they're equivalent
    end
    % terms other than quadratic one
    dphi = -GradLogPost_em_begin + 0.5*TraceInvGdG';
    
    if (randn > 0.5) TimeStep = 1; else TimeStep = -1; end
    
    %RandomSteps = ceil(rand*L); % L = no of leapfrog steps
    
    % Perform leapfrog steps
    for StepNum = 1:L %RandomSteps
        
        % Update velocity %
        %%%%%%%%%%%%%%%%%%%
        % Make a half step for Velocity
        VGamma1 = zeros(nd);
        for d=1:nd
            VGamma1(d,:) = ProposedVelocity'*Gamma1(:,:,d);
        end
        
        if cond((G+(TimeStep*StepSize/2)*VGamma1)) > 1e+15
            posdef = 1;
            break
        end
        
        Deltalogdet = Deltalogdet - log(det(G+(TimeStep*StepSize/2)*VGamma1));
        
        ProposedVelocity = (G+(TimeStep*StepSize/2)*VGamma1)\(G*ProposedVelocity - (TimeStep*StepSize/2)*dphi);
        for d=1:nd
            VGamma1(d,:) = ProposedVelocity'*Gamma1(:,:,d);
        end
        Deltalogdet = Deltalogdet + log(det(G-(TimeStep*StepSize/2)*VGamma1));
        
        % Update position p parameters %
        %%%%%%%%%%%%%%%%%%%%%%%
        % Make a full step for the position
        p = p + (TimeStep*StepSize)*ProposedVelocity;
        
        if any(abs(p)>10) % unrealistic values caused by unreliable metric tensor
            posdef = 1;
            break
        end
        
        % Update G based on new parameters
        em_ind = 1; grad1_SimInd = NaN; grad23_EmInd = [1 1];
        [LogPosterior_em_end, GradLogPost_em_end, GradGradLogPost_em_end, ...
            GradGradGradLogPost_em_end, ~, ~, FirstSecondGradProd_em_end] = ...
            HMCDerivPosterior_all_BioPath_nonzeromean(p', sigma2, trueData, time, tspan, ...
            alp, bet, nd, sc, extra_p, em_ind, phase_ind, grad1_SimInd, ...
            grad23_EmInd, gp_regr, x_regr, y_regr, do_nuts, invLref, H, B, b);
        
        lambda = 0;
        
        G = (1-lambda) .* (-GradGradLogPost_em_end) + lambda .* (GradLogPost_em_end * GradLogPost_em_end');
        
        [~,posdef] = chol(G);
        while (posdef ~= 0) && (lambda < 0.99) && (LogPosterior_em_end ~= -10^10) % avoids getting into an infinite loop
            lambda = lambda + 0.1;
            G = (1-lambda) .* (-GradGradLogPost_em_end) + lambda .* (GradLogPost_em_end * GradLogPost_em_end');
            [~,posdef] = chol(G);
        end
        
        G = G + (1e-06)*eye(nd,nd);
        
        [~,posdef] = chol(G);
        
        if cond(G)>1e+15 % high condition number
            posdef = 1; % posdef from chol can still be 0,
            % but I get warnings that matrix is close to singular or
            % badly scaled when inverting it
        end
        
        if posdef ~= 0
            
            break
            
        else
            
            InvG = inv(G);
            
            % Get the partial derivatives dG/dphi
            GDeriv = NaN(repmat(nd,1,3));
            for d = 1:nd
                GDeriv(:,:,d) = (1-lambda) .* (-GradGradGradLogPost_em_end{d}) + lambda .* FirstSecondGradProd_em_end{d};
            end
            
            Gamma1 = 0.5*(permute(GDeriv,[1,3,2]) + permute(GDeriv,[3,2,1]) - GDeriv);
            
            % Update the partial derivatives dG/dq
            for d = 1:nd
                TraceInvGdG(d) = sum(sum(InvG.*GDeriv(:,:,d)'));
                %or TraceInvGdG(d) = trace(G\GDeriv(:,:,d)); they're equivalent
            end
            % terms other than quadratic one
            dphi = -GradLogPost_em_end + 0.5*TraceInvGdG';
            
            %%%%%%%%%%%%%%%%%%%
            % Update velocity %
            %%%%%%%%%%%%%%%%%%%
            % Make a half step for Velocity
            for d=1:nd
                VGamma1(d,:) = ProposedVelocity'*Gamma1(:,:,d);
            end
            
            if cond((G+(TimeStep*StepSize/2)*VGamma1)) > 1e+15
                posdef = 1;
                break
            end
        
            Deltalogdet = Deltalogdet - log(det(G+(TimeStep*StepSize/2)*VGamma1));
            
            ProposedVelocity = (G+(TimeStep*StepSize/2)*VGamma1)\(G*ProposedVelocity - (TimeStep*StepSize/2)*dphi);
            
            for d=1:nd
                VGamma1(d,:) = ProposedVelocity'*Gamma1(:,:,d);
            end
            
            Deltalogdet = Deltalogdet + log(det(G-(TimeStep*StepSize/2)*VGamma1));
            
        end % posdef
        
    end % StepNum
    
    if posdef == 0 % i.e. no 'break'
        
        ProposedLJL = LogPosterior_em_end;
        
        if ProposedLJL~=-10^10  || ~isreal(ProposedLJL) % only calculate MH ratio for non-zero likelihoods
            
            [CholInvG,posdef] = chol(InvG);
            
            if posdef ~= 0
                
                LogPosterior_em = LogPosterior_em_begin;
                GradLogPost_em = GradLogPost_em_begin;
                GradGradLogPost_em = GradGradLogPost_em_begin;
                GradGradGradLogPost_em = GradGradGradLogPost_em_begin;
                LogPosterior_sim = LogPosterior_sim_begin;
                ObjFct_sim = ObjFct_sim_begin;
                current_p = current_p;
                
                return
                
            else
                
                ProposedLogDet = 0.5*( nd*log(2) + nd*log(pi) + 2*sum(log(diag(CholInvG))));
                
                ProposedH = -ProposedLJL + ProposedLogDet + (ProposedVelocity'*G*ProposedVelocity)/2;
                
                % Accept according to ratio
                Ratio = -ProposedH + CurrentH + Deltalogdet;
                
            end
            
        end
        
        if do_DA == 0 % no delayed acceptance
            
            if ProposedLJL == -10^10 || ~isreal(ProposedLJL) % reject
                %disp('reject because of zero likelihood')
                LogPosterior_em = LogPosterior_em_begin;
                GradLogPost_em = GradLogPost_em_begin;
                GradGradLogPost_em = GradGradLogPost_em_begin;
                GradGradGradLogPost_em = GradGradGradLogPost_em_begin;
                LogPosterior_sim = LogPosterior_sim_begin;
                ObjFct_sim = ObjFct_sim_begin;
                current_p = current_p;
                %current_p
                
            else
                
                CurrentH_sim = -LogPosterior_sim_begin + CurrentLogDet + ...
                    (OriginalVelocity'*OriginalG*OriginalVelocity)/2;
                
                em_ind = 0; grad1_SimInd = 0; grad23_EmInd = [NaN NaN];
                [LogPosterior_sim_end, ~, ~, ~, ~, ObjFct_sim_end] = ...
                    HMCDerivPosterior_all_BioPath_nonzeromean(p', sigma2, trueData, time, tspan, ...
                    alp, bet, nd, sc, extra_p, em_ind, phase_ind, grad1_SimInd, ...
                    grad23_EmInd, gp_regr, x_regr, y_regr, do_nuts, invLref, H, B, b);
                
                noODE_counter = noODE_counter + 1;
                
                ProposedH_sim = -LogPosterior_sim_end + ProposedLogDet + ...
                    (ProposedVelocity'*G*ProposedVelocity)/2;
                
                % Accept according to ratio
                Ratio_sim = -ProposedH_sim + CurrentH_sim + Deltalogdet;
                
                if (isfinite(Ratio_sim) && isreal(Ratio_sim) && (Ratio_sim > min([0,log(rand)]))) % accept
                    %disp('accept')
                    LogPosterior_em = LogPosterior_em_end;
                    GradLogPost_em = GradLogPost_em_end;
                    GradGradLogPost_em = GradGradLogPost_em_end;
                    GradGradGradLogPost_em = GradGradGradLogPost_em_end;
                    LogPosterior_sim = LogPosterior_sim_end;
                    ObjFct_sim = ObjFct_sim_end;
                    current_p = p;
                else
                    %disp('reject')
                    LogPosterior_em = LogPosterior_em_begin;
                    GradLogPost_em = GradLogPost_em_begin;
                    GradGradLogPost_em = GradGradLogPost_em_begin;
                    GradGradGradLogPost_em = GradGradGradLogPost_em_begin;
                    LogPosterior_sim = LogPosterior_sim_begin;
                    ObjFct_sim = ObjFct_sim_begin;
                    current_p = current_p;
                end
                
            end
            
        else % do_DA = 1
            
            if ProposedLJL == -10^10  || ~isreal(ProposedLJL) % reject
                %disp('reject in stage 1 because of zero likelihood')
                LogPosterior_em = LogPosterior_em_begin;
                GradLogPost_em = GradLogPost_em_begin;
                GradGradLogPost_em = GradGradLogPost_em_begin;
                GradGradGradLogPost_em = GradGradGradLogPost_em_begin;
                LogPosterior_sim = LogPosterior_sim_begin;
                ObjFct_sim = ObjFct_sim_begin;
                current_p = current_p;
                
            else
                
                if (isfinite(Ratio) && isreal(Ratio) && (Ratio > min([0,log(rand)]))) % accept in stage 1
                    
                    %disp('accept in stage 1')
                    
                    % next calculate acc rate in stage 2 using the simulator in an MH step
                    em_ind = 0; grad1_SimInd = 0; grad23_EmInd = [NaN NaN];
                    [LogPosterior_sim_end, ~, ~, ~, ~, ObjFct_sim_end] = ...
                        HMCDerivPosterior_all_BioPath_nonzeromean(p', sigma2, trueData, time, tspan, ...
                        alp, bet, nd, sc, extra_p, em_ind, phase_ind, ...
                        grad1_SimInd, grad23_EmInd, ...
                        gp_regr, x_regr, y_regr, do_nuts, invLref, H, B, b);
                    
                    noODE_counter = noODE_counter + 1;
                    
                    %[LogPosterior_sim_begin,LogPosterior_em_begin]
                    %[LogPosterior_sim_end,LogPosterior_em_end]
                    
                    r2 = LogPosterior_sim_end - LogPosterior_sim_begin + ...
                        LogPosterior_em_begin - LogPosterior_em_end;
                    
                    if r2 > 0 || (r2 > log(rand)) % accept at 2nd stage
                        %disp('accept in stage 2')
                        LogPosterior_em = LogPosterior_em_end;
                        GradLogPost_em = GradLogPost_em_end;
                        GradGradLogPost_em = GradGradLogPost_em_end;
                        GradGradGradLogPost_em = GradGradGradLogPost_em_end;
                        LogPosterior_sim = LogPosterior_sim_end;
                        ObjFct_sim = ObjFct_sim_end;
                        current_p = p;
                        
                    else % reject at 2nd stage
                        %disp('reject in stage 2')
                        LogPosterior_em = LogPosterior_em_begin;
                        GradLogPost_em = GradLogPost_em_begin;
                        GradGradLogPost_em = GradGradLogPost_em_begin;
                        GradGradGradLogPost_em = GradGradGradLogPost_em_begin;
                        LogPosterior_sim = LogPosterior_sim_begin;
                        ObjFct_sim = ObjFct_sim_begin;
                        current_p = current_p;
                        
                    end
                    
                else % reject in stage 1
                    %disp('reject in stage 1')
                    LogPosterior_em = LogPosterior_em_begin;
                    GradLogPost_em = GradLogPost_em_begin;
                    GradGradLogPost_em = GradGradLogPost_em_begin;
                    GradGradGradLogPost_em = GradGradGradLogPost_em_begin;
                    LogPosterior_sim = LogPosterior_sim_begin;
                    ObjFct_sim = ObjFct_sim_begin;
                    current_p = current_p;
                    
                end
                
            end % ProposedLJL
            
        end % do_DA
        
    else % posdef~=0, i.e. break
        
        LogPosterior_em = LogPosterior_em_begin;
        GradLogPost_em = GradLogPost_em_begin;
        GradGradLogPost_em = GradGradLogPost_em_begin;
        GradGradGradLogPost_em = GradGradGradLogPost_em_begin;
        LogPosterior_sim = LogPosterior_sim_begin;
        ObjFct_sim = ObjFct_sim_begin;
        current_p = current_p;
        
    end
    
end % posdef

end