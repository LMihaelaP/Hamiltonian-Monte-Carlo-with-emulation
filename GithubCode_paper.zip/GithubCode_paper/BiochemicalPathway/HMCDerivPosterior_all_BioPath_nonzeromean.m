function [LogPosterior, GradLogPosterior, GradGradLogPosteriorMatrix, ...
    GradGradGradLogPosteriorMatrix, Var, ObjFct, FirstSecondGradProd] = ...
    HMCDerivPosterior_all_BioPath_nonzeromean(param_sc, ...
    sigma2, trueData, time, tspan, alp, bet, nd, sc, extra_p, ...
    em_ind, phase_ind, grad1_SimInd, grad23_EmInd, ...
    gp_regr, x_regr, y_regr, do_nuts, invLref, H, B, b)
% Function that calculates the LogPosterior distr and its gradient for both
% the simulator (needed at end of trajectory) - when em_ind = 0
% and the emulator (needed throughout the trajectory) - when em_ind = 1
% Also returns Var from emulator to check if sqrt(Var) > 3,
% i.e. stop the trajectory in HMC?

% Input
% param_sc: (nd,1) vector -- parameters scaled to make them unbounded
% alp, bet: (nd,1) vectors -- hyperparameters for the prior distr
% sc: the constant scaling factors used in emulation
% em_ind: emulation index that indicates if we simulate (0) or emulate (1)
% the objective function: RSS
% phase_ind: GPHMC algthm phase index - 1: exploratory, 2: sampling phase
%            as E_potential different for the 2 phases
% grad1_SimInd: indicates if we calculate 1st gradient of the log posterior
% coming from the simulator (can be 0 at the end of the trajectory
% when we accept/reject based on MH step, ie no GradLogPost needed; can be 1 if
% we use the simulator throughout the trajectory, ie GradLogPost needed).
% grad23_EmInd: 2x1 indicator vector: says if we calculate 2nd & 3rd gradient of the log posterior
% coming from the emulator (only done in the sampling phase),
% i.e. whether we do HMC/NUTS or RMHMC/LDMC
% gp_regr, x_regr, y_regr: GP regression used throughout the trajectory
% mean_y, std_y: used to make y_regr zero mean, unit variance
% invLref is the inverse of the GP covariance matrix
% H, B, b needed for the non-zero mean GP model
% Output
% LogPosterior, 1st, 2nd, 3rd Gradient LogPosterior
% Var to check if sqrt(Var) > 3, i.e. stop the trajectory in HMC?
% ObjFct value: RSS

ns = size(y_regr,2); % no of species

invL = cell(ns,1);

for is=1:ns
    invL{is} = invLref(is).array; % inverse of the choleski decomp matrix for the emulator
    % covariance matrix passed over by reference
end

n = size(trueData,1);

if do_nuts == 1
    param_sc = param_sc';
end

param = exp(param_sc);

Jacob = param;

Sign = -1; % for rss to be used in phase_ind=1

if em_ind == 0
    
    if any(isnan(param)) || any(~isfinite(param)) || any(~isreal(param))
        %disp('The LogLikGradient is too high, change values of L and epsilon')
        ObjFct = repmat(10^10/ns,1,ns); pass = 0;
    else
        
        [ObjFct, Z, new_data] = Run_simulator_BioPath(param./sc, time, ...
            tspan, trueData, sc, extra_p);
        
        if any(ObjFct) ~= 10^10/ns
            pass = 1;
        else
            pass = 0;
        end
    end
    
    % Compute the simulated log likelihood and its gradient
    LogLik_tot = sum ( -n/2.*log(sigma2)-n/2*log(2*pi)*size(sigma2,1) - ...
        ObjFct./(2.*sigma2) );
    
    if grad1_SimInd == 1 && pass == 1
        % we may need this if algorithm based on the simulator only is run
        FirstDeriv_theta = BlackBoxFirstDeriv_theta_BioPath2(new_data, ...
            param, time, tspan, nd, extra_p);
        
        GradLogLik_tot = zeros(nd,1);
        
        for is=1:ns
            GradLogLik_tot = GradLogLik_tot + ...
                (1/sigma2(is)) * (FirstDeriv_theta(:,((is-1)*n+1):(is*n)) * Z(:,is))  .* Jacob';
        end
        
    else % grad1_SimInd = 0
        
        GradLogLik_tot = NaN(nd,1);
        
    end
    
    % Assign Var of GP prediction Inf since here simulator used
    Var = Inf(1,ns);
    
else % em_ind == 1
    %%%%%%%%%%%% here compute emulated loglik and derivative of emulated loglik
    %%%%%%
    
    param_em =  param./sc; % parameters used in emulation
    
    ScJacob = ((1./sc)' .* Jacob'); % scaled Jacob (d,1)
    
    % Calculate 1st gradient of Jacobian
    dJacob = param;
    
    ScdJacob = ((1./sc) .* dJacob)'; % scaled first order deriv of Jacob (d,1)
    
    % Calculate 2nd gradient of Jacobian
    d2Jacob = param;
    
    Scd2Jacob = ((1./sc) .* d2Jacob )'; % scaled second order deriv of Jacob (d,1)
    
    ObjFct = NaN(1,ns); E = NaN(1,ns); Var = NaN(1,ns); LogLik = NaN(ns,1);
    GradLogLik = NaN(nd,ns); GradGradLogLikMatrix = cell(ns,1);
    GradGradGradLogLikMatrix = cell(nd,ns);
    
    
    for is = 1:ns
        
        if any(isnan(param_em)) || any(~isfinite(param_em)) || any(~isreal(param_em))
            %disp('The LogLikGradient is too high, change values of L and epsilon')
            ObjFct(is) = 10^10/ns; pass = 0; Var(is) = Inf;
            
        else
            
            a = invL{is}' * (invL{is}*y_regr(:,is)); % (n,1)        % a = L'\(L\y_regr);
            magnS2 = gp_regr(is).cf{1}.magnSigma2; % (1,1)
            lgtScales = gp_regr(is).cf{1}.lengthScale; % (1,d)
            Lambda = diag(1./(lgtScales.^2)); % (d,d)
            
            % Construct: magnS2 * exp(-0.5*((x-y)*Lambda*(x-y)'))
            AT = ( repmat(param_em,size(x_regr,1),1) - x_regr ) * Lambda; % (n,d)
            BT = ( repmat(param_em,size(x_regr,1),1) - x_regr )'; % (d,n)
            
            CT = sum(AT.*BT',2)'; % (1,n)
            
            if all(isfinite(CT))
                sek = magnS2 .* exp(-0.5.*CT); % (1,n)
                
                if  isfield(gp_regr(is),'meanf')
                    Hnew = [1;param_em(1); param_em(2); param_em(3); ...
                        param_em(4); param_em(5);
                        param_em(1)^2;param_em(2)^2; param_em(3)^2; ...
                        param_em(4)^2;param_em(5)^2;param_em(1)*param_em(2);...
                        param_em(1)*param_em(3); param_em(1)*param_em(4);...
                        param_em(1)*param_em(5);param_em(2)*param_em(3);...
                        param_em(2)*param_em(4);param_em(2)*param_em(5);...
                        param_em(3)*param_em(4);param_em(3)*param_em(5);...
                        param_em(4)*param_em(5)]; % (l,1), where l = no of regression coefficients
                    
                    CinvKnew = invL{is}'*(invL{is}*sek');  % (n,1) % inv(C)*K(x_regr,param_em)
                    CinvH = invL{is}'*(invL{is}*H'); % (n,l)  % inv(C)*H'
                    
                    R = Hnew - H*CinvKnew; % (l,1)
                    
                    invB = B\eye(size(B)); %(l,l)
                    B1 = invB + H*CinvH; %(l,l)
                    B2 = H*a + invB*b; %(l,1)
                    
                    invB1 = B1\eye(size(B1)); %(l,l)
                    betaBar = invB1*B2; %(l,1)
                    
                    invAR = invB1 * R; %(l,1)
                    RARapu = R'.*invAR';  % (1,l)
                    
                    Rbet  = R'*betaBar; % (1,1)             % For predictive mean
                    RAR = sum(RARapu,2); % (1,1)       % For predictive variance
                    
                end
                
                %
                E(is) = sek * a; % (1,1)
                
                if  isfield(gp_regr(is),'meanf')
                    E(is) = E(is) + Rbet; % if a non-zero mean is used
                end
                
                %[Eft, Varft] = gp_pred(gp_regr(is), x_regr, y_regr(:,is), param_em);
                
                v = invL{is}*sek'; % v = L\sek';
                Var(is) = magnS2 - v'*v; % (1,1)
                
                if  isfield(gp_regr(is),'meanf')
                    Var(is) = Var(is) + RAR; % if a non-zero mean is used
                end
                
                if Var(is) < 1e-09
                    Var(is) = 1e-09;
                end
                
                pass = 1;
                
                if phase_ind == 1 % exploratory phase
                    ObjFct(is) = E(is) + Sign * sqrt(Var(is)); % E - sqrt(Var)
                else % phase_ind == 2 => sampling phase
                    ObjFct(is) = E(is);
                end
                
            else
                
                ObjFct(is) = 10^10/ns; pass = 0; Var(is) = Inf;
                
            end
            
        end
        
        % Now compute the emulated log likelihood and its gradient
        LogLik(is) = -n/2*log(sigma2(is))-n/2*log(2*pi) - ObjFct(is)/(2*sigma2(is));
        
        if pass == 0
            
            GradLogLik(:,is) = -(1/(2*sigma2(is))) * zeros(nd,1); % (d,1)
            
        else
            
              [d1H,d2H] = CalcBasisFctsDeriv(param_em); % derivatives of the basis functions
            % d1H:(l,d), d2H: d matrices of size (l,d) each
            
            q1 = Lambda * BT; % (d,n)
            q4 = 1/(2*sigma2(is)); % (1,1)
            
            FirstDerivKernel = - q1 .* sek; % (d,n) since (d,n) .* (1,n) = (d,n)
            
            FirstDerivGPpostMean = FirstDerivKernel * a; % first order derivative of the GP posterior mean (d,1)
            
            if  isfield(gp_regr(is),'meanf')
                d1R = d1H - H * (invL{is}'*(invL{is}*FirstDerivKernel')); % (l,d)
                d1Rbet = d1R' * betaBar; % (d,1)
                FirstDerivGPpostMean = FirstDerivGPpostMean + d1Rbet;
            end
            
            GradLogLik(:,is) = (-q4 * FirstDerivGPpostMean) .* ScJacob; % (d,1)
            
            if phase_ind == 1
                                
                q5 = v'*invL{is};
                
                FirstDerivGPpostVar = -2 * q5 * FirstDerivKernel';
                FirstDerivGPpostVar = FirstDerivGPpostVar'; %(d,1)
                
                if  isfield(gp_regr(is),'meanf')
                    d1RAR = d1R' * invB1 * R + (R' * invB1 * d1R)'; % (d,1)
                    FirstDerivGPpostVar = FirstDerivGPpostVar + d1RAR;
                end
                
                GradLogLik(:,is) = GradLogLik(:,is) + ( -q4 * Sign * 1/(2*sqrt(Var(is))) * ...
                    FirstDerivGPpostVar ) .* ScJacob; % (d,1)
                
            end % phase_ind
            
            if grad23_EmInd(1) == 1 % 2nd order derivative of the emulated Log Lik
                
                % Get the d2f/dx2 component
                SecondDerivKernel = - Lambda * ( ones(nd,1) * sek + BT .* FirstDerivKernel ); % (d,n)
                
                SecondDerivGPpostMean = SecondDerivKernel * a; % second order derivative of the GP posterior mean (d,1)
                                
                SecondDerivGPpostMeanMatrix = diag ( SecondDerivGPpostMean ); % (d,d)
                
                l = size(B,1); % no of regression coefficients
                
                if  isfield(gp_regr(is),'meanf')
                                        
                    d2h_tmp = NaN(l,nd);
                    for i=1:nd
                        d2h_tmp(:,i) = d2H{i}(:,i); % (l,d)
                    end
                    
                    % Get the d2f/dx2 component
                    d2Rbet = (d2h_tmp - H * (invL{is}'*(invL{is}*SecondDerivKernel')) )' * betaBar; % (d,1)
                    
                    SecondDerivGPpostMean = SecondDerivGPpostMean + d2Rbet; % (d,1)
                    
                    Q = ScJacob .* SecondDerivGPpostMean; % (d,1)

                    SecondDerivGPpostMeanMatrix = SecondDerivGPpostMeanMatrix + ...
                        diag( d2Rbet );
                end
                
                GradGradLogLikMatrix{is} = diag( -q4 *...
                    ( (Q .* ScJacob ) + FirstDerivGPpostMean .* ScdJacob ) ); % (d,d)
                
                % Get the d2f/dxdy component
                SecondPartialDerivKernel = @(k,j) ( -Lambda(j,j) * BT(j,:) .* FirstDerivKernel(k,:) ); % (1,n) for every (j,k) combination
                d2RbetPartial = @(k,j) ( (d2H{k}(:,j) - H * (invL{is}'*(invL{is}*SecondPartialDerivKernel(k,j)')))' * betaBar ); % (1,1) for every (j,k) combination
                
                for k=2:nd
                    for j = 1:k-1
                        SecondDerivGPpostMeanMatrix(k,j) = SecondPartialDerivKernel(k,j) * a; % (1,1) for every (j,k) combination
                        
                        if  isfield(gp_regr(is),'meanf')
                            
                            SecondDerivGPpostMeanMatrix(k,j) = SecondDerivGPpostMeanMatrix(k,j) + ...
                                d2RbetPartial(k,j); % (1,1)
                        end
                        
                        SecondDerivGPpostMeanMatrix(j,k) = SecondDerivGPpostMeanMatrix(k,j); % matrix is symmetric
                        
                        GradGradLogLikMatrix{is}(k,j) = -q4 * ( SecondDerivGPpostMeanMatrix(k,j) * ScJacob(k) * ScJacob(j) ); % (1,1) for every (k,j) combination
                        GradGradLogLikMatrix{is}(j,k) = GradGradLogLikMatrix{is}(k,j); % matrix is symmetric
                    end
                end
                
                if grad23_EmInd(2) == 1 % 3rd order derivative of the emulated Log Lik
                    % (RMHMC, LDMC)
                    
                    % Get the d3f/dx3 component
                    ThirdDerivKernel = - Lambda * ( 2 * ones(nd,size(x_regr,1)) .* FirstDerivKernel + BT .* SecondDerivKernel  ); %(d,n)
                    
                    ThirdDerivGPpostMean = ThirdDerivKernel * a; % third order derivative of the GP posterior mean (d,1)
                    
                    if  isfield(gp_regr(is),'meanf')
                        d3H = zeros(l,nd); % d3H is actually d^2 matrices of size (l,nd) each and each equals the zero matrix
                        
                        % Get the d3f/dx3 component
                        d3Rbet = (d3H - H * (invL{is}'*(invL{is}*ThirdDerivKernel')) )' * betaBar; % (d,1)
                        
                        ThirdDerivGPpostMean = ThirdDerivGPpostMean + d3Rbet;
                    end
                    
                    ThirdDerivGPpostMeanMatrix = cell(nd,1);
                    
                    for m=1:nd
                        for k=1:nd
                            for j=1:k
                                if m==k && m==j
                                    
                                    ThirdDerivGPpostMeanMatrix{m}(k,j) = ThirdDerivGPpostMean(m); % (1,1) ThirdDerivKernel * a
                                    
                                    GradGradGradLogLikMatrix{m,is}(k,j) = -q4 *...
                                        ( ( ThirdDerivGPpostMean(m) * ScJacob(m)^3 ) + ( 3 * Q(m) * ScdJacob(m) ) + ...
                                        ( FirstDerivGPpostMean(m) * Scd2Jacob(m) ) );
                                    
                                elseif m==k && m~=j
                                    
                                    ThirdDerivPartialKernel = ( -Lambda(j,j) * BT(j,:) .* SecondDerivKernel(k,:) ); % (1,n)
                                    ThirdDerivGPpostMeanMatrix{m}(k,j) = ThirdDerivPartialKernel * a; % (1,1)
                                    
                                    if  isfield(gp_regr(is),'meanf')
                                        d3RbetPartial = (d3H(:,1) - H * (invL{is}'*(invL{is}*ThirdDerivPartialKernel')) )' * betaBar; % (1,1)
                                        ThirdDerivGPpostMeanMatrix{m}(k,j) = ThirdDerivGPpostMeanMatrix{m}(k,j) + d3RbetPartial;
                                    end
                                    
                                    GradGradGradLogLikMatrix{m,is}(k,j) = -q4 *...
                                        ( ThirdDerivGPpostMeanMatrix{k}(k,j) * ScJacob(k)^2 * ScJacob(j) + SecondDerivGPpostMeanMatrix(k,j) * ScdJacob(k) * ScJacob(j) );
                                    
                                elseif m==j && m~=k
                                    
                                    ThirdDerivPartialKernel = ( -Lambda(j,j) * ( FirstDerivKernel(k,:) + BT(j,:) .* SecondPartialDerivKernel(j,k) ) ); % (1,n)
                                    ThirdDerivGPpostMeanMatrix{m}(k,j) = ThirdDerivPartialKernel * a; % (1,1)
                                    
                                    if  isfield(gp_regr(is),'meanf')
                                        d3RbetPartial = (d3H(:,1) - H * (invL{is}'*(invL{is}*ThirdDerivPartialKernel')) )' * betaBar; % (1,1)
                                        ThirdDerivGPpostMeanMatrix{m}(k,j) = ThirdDerivGPpostMeanMatrix{m}(k,j) + d3RbetPartial;
                                    end
                                    
                                    GradGradGradLogLikMatrix{m,is}(k,j) = -q4 *...
                                        ( ThirdDerivGPpostMeanMatrix{j}(k,j) * ScJacob(j)^2 * ScJacob(k) + SecondDerivGPpostMeanMatrix(k,j) * ScJacob(k) * ScdJacob(j) );
                                    
                                elseif j==k && m~=j
                                    
                                    ThirdDerivPartialKernel = ( -Lambda(j,j) * ( FirstDerivKernel(m,:) + BT(j,:) .* SecondPartialDerivKernel(m,j) ) ); % (1,n)
                                    ThirdDerivGPpostMeanMatrix{m}(k,j) = ThirdDerivPartialKernel * a; % (1,1)
                                    
                                    if  isfield(gp_regr(is),'meanf')
                                        d3RbetPartial = (d3H(:,1) - H * (invL{is}'*(invL{is}*ThirdDerivPartialKernel')) )' * betaBar; % (1,1)
                                        ThirdDerivGPpostMeanMatrix{m}(k,j) = ThirdDerivGPpostMeanMatrix{m}(k,j) + d3RbetPartial;
                                    end
                                    
                                    GradGradGradLogLikMatrix{m,is}(k,j) = -q4 *...
                                        ( ThirdDerivGPpostMeanMatrix{m}(j,j) * ScJacob(m) * ScJacob(j)^2 + SecondDerivGPpostMeanMatrix(m,j) * ScJacob(m) * ScdJacob(j) );
                                    
                                else % m~=k~=j
                                    
                                    ThirdDerivPartialKernel = ( -Lambda(j,j) * BT(j,:) .* SecondPartialDerivKernel(m,k) ); % (1,n)
                                    ThirdDerivGPpostMeanMatrix{m}(k,j) = ThirdDerivPartialKernel * a; % (1,1)
                                    
                                    if  isfield(gp_regr(is),'meanf')
                                        d3RbetPartial = (d3H(:,1) - H * (invL{is}'*(invL{is}*ThirdDerivPartialKernel')) )' * betaBar; % (1,1)
                                        ThirdDerivGPpostMeanMatrix{m}(k,j) = ThirdDerivGPpostMeanMatrix{m}(k,j) + d3RbetPartial;
                                    end
                                    
                                    GradGradGradLogLikMatrix{m,is}(k,j) = -q4 *...
                                        ( ThirdDerivGPpostMeanMatrix{m}(k,j) * ScJacob(m) * ScJacob(k) * ScJacob(j) );
                                    
                                end
                                
                                GradGradGradLogLikMatrix{m,is}(j,k) = GradGradGradLogLikMatrix{m,is}(k,j); % matrix is symmetric
                                
                            end
                        end
                    end
                    
                end % grad23_EmInd(2)
                
            end % grad23_EmInd(1)             
            
        end %pass
        
    end % is
end % em_ind

if em_ind == 1
    
    % sum likelihood terms 1 and 2 to get the total
    LogLik_tot = sum(LogLik); % (1,1)
    
    GradLogLik_tot = sum(GradLogLik,2); % (d,1)
    
    if grad23_EmInd(1) == 1
        
        try
        GradGradLogLikMatrix_tot = plus(plus(GradGradLogLikMatrix{1:2}),plus(GradGradLogLikMatrix{3:4})); % (d,d)
        %GradGradLogLikMatrix{:}
        catch
            pass = 0;
        end
        
        if grad23_EmInd(2) == 1
            
            GradGradGradLogLikMatrix_tot = cell(nd,1); % d matrices of size (d,d) each
            
            try
                
            for m=1:nd
                
                GradGradGradLogLikMatrix_tot{m} = plus(plus(GradGradGradLogLikMatrix{m,1:2}),...
                    plus(GradGradGradLogLikMatrix{m,3:4})); % (d,d)
                
            end
            
            catch
            pass = 0;
            end
        
        end
    end
end


LogPrior = sum ( -log(gamma(alp)) - alp .* log(bet) + alp .* param_sc - param./bet );

GradLogPrior = alp - param./bet;
GradLogPrior = GradLogPrior';

if em_ind == 1 && grad23_EmInd(1) == 1
    % second derivative of the prior
    GradGradLogPrior = - param./bet;
    GradGradLogPriorMatrix = diag ( GradGradLogPrior ); % and the off-diagonal elements are zero
    
    
    if grad23_EmInd(2) == 1
        % 3rd derivative of the prior
        GradGradGradLogPrior = - param./bet;
        GradGradGradLogPriorMatrix = cell(nd,1); % contains d matrices
        
        for m=1:nd
            GradGradGradLogPriorMatrix{m} = zeros(nd,nd);
            GradGradGradLogPriorMatrix{m}(m,m) = GradGradGradLogPrior(m);
        end
    end % grad23_EmInd(2)
    
end % em_ind && grad23_EmInd(1)

if pass == 1
    
    LogPosterior = LogLik_tot + LogPrior;
    
    GradLogPosterior = GradLogLik_tot + GradLogPrior;
    
    if em_ind == 1 && grad23_EmInd(1) == 1 && phase_ind == 2
        
        GradGradLogPosteriorMatrix = GradGradLogLikMatrix_tot + GradGradLogPriorMatrix;
        
        if grad23_EmInd(2) == 1
            
            GradGradGradLogPosteriorMatrix = cell(nd,1); % contains d matrices
            
            for m=1:nd
                GradGradGradLogPosteriorMatrix{m} = ...
                    GradGradGradLogLikMatrix_tot{m} + GradGradGradLogPriorMatrix{m};
            end
            
        else
            
            GradGradGradLogPosteriorMatrix = NaN; % not needed
            
        end % grad23_EmInd(2)
        
        FirstSecondGradProd = cell(nd,1);
        
        for k=1:nd
            
            FirstSecondGradProd{k} = zeros(nd,nd);
            
            for j=1:nd
                for i=1:nd
                    FirstSecondGradProd{k}(j,i) = GradGradLogPosteriorMatrix(k,j) * GradLogPosterior(i) + ...
                        GradLogPosterior(j) * GradGradLogPosteriorMatrix(k,i);
                    
                    FirstSecondGradProd{k}(i,j) = FirstSecondGradProd{k}(j,i); % matrix is symmetric
                end
            end
            
        end
        
    else
        % NaNs if phase_ind = 1, for which we do not need 2nd and 3rd derivative
        
        GradGradLogPosteriorMatrix = NaN; % not needed in our code
        
        GradGradGradLogPosteriorMatrix = NaN; % not needed in our code
        
        FirstSecondGradProd = NaN; % not needed in our code
        
    end
    
else % pass = 0
    
    LogPosterior = -10^10; % equivalent to Posterior = 0
    GradLogPosterior = zeros(nd,1);
    
    if em_ind == 1 && grad23_EmInd(1) == 1 && phase_ind == 2
        GradGradLogPosteriorMatrix = zeros(nd,nd);
        if grad23_EmInd(2) == 1
            GradGradGradLogPosteriorMatrix = cell(nd,1); % contains d matrices
            for m=1:nd
                GradGradGradLogPosteriorMatrix{m} = zeros(nd,nd);
            end
        else
            GradGradGradLogPosteriorMatrix = NaN; % not needed
            
        end % grad23_EmInd(2)
        
        FirstSecondGradProd = cell(nd,1); % contains d matrices
        
        for m=1:nd
            FirstSecondGradProd{m} = zeros(nd,nd);
        end
        
    else
        % NaNs if phase_ind = 1, for which we do not need 2nd and 3rd derivative
        
        GradGradLogPosteriorMatrix = NaN; % not needed
        GradGradGradLogPosteriorMatrix = NaN; % not needed
        FirstSecondGradProd = NaN; % not needed in our code
        
    end % grad23_EmInd(1)
    
end % pass

end