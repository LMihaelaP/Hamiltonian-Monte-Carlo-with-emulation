function FirstDeriv = BlackBoxFirstDeriv_theta_BioPath2(new_data, param, ...
    time, tspan, nd, extra_p)

% Calculates the (simulator) derivative of the black-box Biopath w.r.t. every parameter

% output: the first derivative for every parameter

FirstDeriv = NaN(nd, numel(new_data));

h = 1e-4; % differentiation step size

parfor i = 1:nd
    
    if i == 1
        param_hplus = [param(1)+h, param(2:end)];
        param_hminus = [param(1)-h, param(2:end)];
        
    elseif i == 2
        param_hplus = [param(1), param(2)+h, param(3:end)];
        param_hminus = [param(1), param(2)-h, param(3:end)];
        
    elseif i==3
        param_hplus = [param(1:2), param(3)+h, param(4:5)];
        param_hminus = [param(1:2), param(3)-h, param(4:5)];
        
    elseif i==4
        param_hplus = [param(1:3), param(4)+h, param(5)];
        param_hminus = [param(1:3), param(4)-h, param(5)];
        
    else
        param_hplus = [param(1:4), param(5)+h];
        param_hminus = [param(1:4), param(5)-h];
        
    end
    
    options = odeset('RelTol',1e-6,'AbsTol',1e-6);
    
    try
        
        % stable
        [~,new_data_hplus] = ode23( @(t,y) SolveODEs_BioPath(t, y, param_hplus), time, extra_p, options );
        [~,new_data_hminus] = ode23( @(t,y) SolveODEs_BioPath(t, y, param_hminus), time, extra_p, options );
        
    catch
        
        new_data_hminus = NaN(size(trueData,1),size(trueData,2));
        
        new_data_hplus = NaN(size(trueData,1),size(trueData,2));
        
        
    end
    
    FirstDeriv(i,:) = (new_data_hplus(:) - new_data_hminus(:))./(2*h);
    
end


end