function [ObjFct, Z, new_data] = Run_simulator_BioPath(x, time, tspan, trueData, sc, extra_p)

% total number of time points = no of species * no of time points per species
ntp = size(trueData,1);

ns = size(trueData,2);

param = x .* sc;

% extra_p contain the initial values for the species

n = size(x,1);

NLL = NaN(n,ns); Z = NaN(ntp,ns);

for i = 1:n
    
    if any(param(i,1:5)>10^3) || any(param(i,1:5)<10^(-5))
        % can be anything that is too large or too small that causes numerical issues for the ode solver
        
        new_data = NaN(size(trueData,1),size(trueData,2));
        
        for is=1:ns
            
            Z(:,is) = NaN(ntp,1);
            
            NLL(i, is) = 10^10/ns;
            
        end
        
    else
        
        [timedata, new_data] = ode23( @(t,y) SolveODEs_BioPath(t, y, param(i,1:5)), time, extra_p );
        
        for is=1:ns
            
            Z(:,is) = trueData(:,is) - new_data(:,is); % for all 2 species
            
            NLL(i,is) = sum(Z(:,is).^2); % for every species
            
        end
        
    end
    
    ObjFct = NLL;
    
end

end

