function dsoldt = SolveODEs_BioPath(t, y, param)
% Solves a system of nonlinear ODEs for the Biochemical Signaling Pathways

% Parameters
k1 = param(1); V1 = param(2); Km1 = param(3); V2 = param(4); Km2 = param(5);

% Species
S = y(1); D = y(2); R = y(3); Rpp = y(4);

dsoldt = [ - k1 * S; k1 * S; -( V1 * R * S ) / ( Km1 + R ) + ( V2 * Rpp ) / ( Km2 + Rpp ); ...
    ( V1 * R * S ) / ( Km1 + R ) - ( V2 * Rpp ) / ( Km2 + Rpp ) ];

end

