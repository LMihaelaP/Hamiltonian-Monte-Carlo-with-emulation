function [LogPosterior, GradLogPosterior, GradGradLogPosteriorMatrix, ...
    GradGradGradLogPosteriorMatrix, Var, LogLik, FirstSecondGradProd] = ...
    Sin_HMCDerivPosterior_all(param_sc, ...
    x, y, sigma2, GP_hyperHyper, gp_regr, x_regr, y_regr, sc, nd, phase_ind, ...
    em_ind, grad23_EmInd, mean_y, std_y, do_nuts, invLref)

invL = invLref.array; % inverse of the choleski decomp matrix for the emulator
% covariance matrix passed over by reference

if do_nuts == 1
    param_sc = param_sc';
end

param = exp(param_sc); % original scale

A = param(1); B = param(2); C = param(3);

Jacob = param; % jacobian

n = size(y,2);

Sign = 1; % indicates whether E + or - sqrt(Var) for the objective function in phase_ind = 1 (-1 for rss and 1 for loglik)


if em_ind == 0 % use simulator
    
    if any(isnan(param)) || any(~isfinite(param)) || any(~isreal(param))
        ObjFct = -10^10; pass = 0;
        
    else
        
        fx = A * sin(B*(x+C));
        
        ObjFct = -n/2*log(sigma2)-n/2*log(2*pi) - sum((y-fx).^2)/(2*sigma2);
        
        fxderiv1 = [sin(B.*(x+C)); A .* cos(B.*(x+C)) .* (x+C); A .* cos(B.*(x+C)).* B];
        
        GradLogLik = (1/sigma2) * (fxderiv1 * (y-fx)' ) .* Jacob';
        
        pass = 1;
        
    end
    
    LogLik = ObjFct;
    
    % Assign Var of GP prediction Inf since here simulator used
    Var = Inf;
    
else % use emulator
    
    param_em =  param./sc; % parameters used in emulation
    
    if any(isnan(param_em)) || any(~isfinite(param_em)) || any(~isreal(param_em))
        %disp('The LogLikGradient is too high, change values of L and epsilon')
        ObjFct = -10^10; Var = Inf; pass = 0;
        
    else
        %[E,Var] = gp_pred(gp_regr, x_regr, y_regr, param_em);
        %[~,Cov] = gp_trcov(gp_regr, x_regr);
        %L = chol(Cov,'lower');   Cov = L'L; Cov^(-1) = (L'L)^(-1) = (L')^(-1)(L^(-1)) = (L^(-1))'(L^(-1))
        
        % invL is the inverse of L, i.e. L\eye or eye/L
        % also, (L')^(-1) = (L^(-1))', inverse of transpose is
        % transpose of inverse for a triangular matrix
        
        a = invL' * (invL*y_regr); % (n,1)        % a = L'\(L\y_regr);
        magnS2 = gp_regr.cf{1}.magnSigma2; % (1,1)
        lgtScales = gp_regr.cf{1}.lengthScale; % (1,d)
        Lambda = diag(1./(lgtScales.^2)); % (d,d)
        
        % Construct: magnS2 * exp(-0.5*((x-y)*Lambda*(x-y)'))
        AT = ( repmat(param_em,size(x_regr,1),1) - x_regr ) * Lambda; % (n,d)
        BT = ( repmat(param_em,size(x_regr,1),1) - x_regr )'; % (d,n)
        
        CT = sum(AT.*BT',2)'; % (1,n)
        
        sek = magnS2 .* exp(-0.5.*CT); % (1,n)
        
        E = sek * a;
        v = invL*sek';
        Var = magnS2 - v'*v;
        
        if Var < 1e-09
            Var = 1e-09;
        end
        
        pass = 1;
        
        if phase_ind == 1 % exploratory phase
            ObjFct = (E + Sign * sqrt(Var)) * std_y + mean_y; % E+sqrt(Var)
            
        else % phase_ind == 2 => sampling phase
            ObjFct = E * std_y + mean_y;
        end
        
    end
    
    % Now compute the emulated log likelihood and its gradient
    LogLik = ObjFct;
    
    if pass == 0
        
        GradLogLik = zeros(nd,1);
        
    else
        
        q1 = Lambda * BT; % (d,n)
        
        ScJacob = ((1./sc)' .* Jacob'); % scaled Jacob (d,1)
        
        FirstDerivKernel = - q1 .* sek; % (d,n) since (d,n) .* (1,n) = (d,n)
        
        FirstDerivGPpostMean = FirstDerivKernel * a; % first order derivative of the GP posterior mean (d,1)
        
        GradLogLik = std_y * FirstDerivGPpostMean .* ScJacob; % (d,1)
        
        
        if phase_ind == 1 % exploratory phase
                        
            q5 = v'*invL;
            
            FirstDerivGPpostVar = -2 * q5 * FirstDerivKernel';
            FirstDerivGPpostVar = FirstDerivGPpostVar'; %(d,1)
            
            GradLogLik = GradLogLik + ( std_y * Sign * ...
                1/(2*sqrt(Var)) * (FirstDerivGPpostVar ) ).* ScJacob;  % (d,1)
            
        end % phase_ind
        
        if grad23_EmInd(1) == 1
            
            % Get the d2f/dx2 component
            SecondDerivKernel = - Lambda * ( ones(nd,1) * sek + BT .* FirstDerivKernel ); % (d,n)
            
            SecondDerivGPpostMean = SecondDerivKernel * a; % second order derivative of the GP posterior mean (d,1)
            
            Q = ScJacob .* SecondDerivGPpostMean; % (d,1)
            
            % Calculate 1st gradient of Jacobian
            dJacob = param; % (1,d)
            
            ScdJacob = ((1./sc) .* dJacob)'; % scaled first order deriv of Jacob (d,1)
            
            Q = ScJacob .* SecondDerivGPpostMean; % (d,1)
            
            SecondDerivGPpostMeanMatrix = diag ( SecondDerivGPpostMean ); % (d,d)
            
            GradGradLogLikMatrix = diag( std_y *...
                ( (Q .* ScJacob ) + FirstDerivGPpostMean .* ScdJacob ) ); % (d,d)
            
            % Get the d2f/dxdy component
            SecondPartialDerivKernel = @(k,j) ( -Lambda(j,j) * BT(j,:) .* FirstDerivKernel(k,:) ); % (1,n) for every (j,k) combination
            
            for k=2:nd
                for j = 1:k-1
                    SecondDerivGPpostMeanMatrix(k,j) = SecondPartialDerivKernel(k,j) * a; % (1,1) for every (j,k) combination
                    SecondDerivGPpostMeanMatrix(j,k) = SecondDerivGPpostMeanMatrix(k,j); % matrix is symmetric
                    
                    GradGradLogLikMatrix(k,j) = std_y * ( SecondDerivGPpostMeanMatrix(k,j) * ScJacob(k) * ScJacob(j) ); % (1,1) for every (k,j) combination
                    GradGradLogLikMatrix(j,k) = GradGradLogLikMatrix(k,j); % matrix is symmetric
                end
            end
            
            if grad23_EmInd(2) == 1
                % (RMHMC, LDMC)
                
                % Get the d3f/dxdydz component
                ThirdDerivKernel = - Lambda * ( 2 * ones(nd,size(x_regr,1)) .* FirstDerivKernel + BT .* SecondDerivKernel  ); %(d,n)
                
                ThirdDerivGPpostMean = ThirdDerivKernel * a; % third order derivative of the GP posterior mean (d,1)
                
                % Calculate 2nd gradient of Jacobian
                d2Jacob = param; % (1,d)
                
                Scd2Jacob = ((1./sc) .* d2Jacob )'; % scaled second order deriv of Jacob (d,1)
                
                ThirdDerivGPpostMeanMatrix = cell(nd,1);
                GradGradGradLogLikMatrix = cell(nd,1);
                
                for m=1:nd
                    for k=1:nd
                        for j=1:k
                            if m==k && m==j
                                
                                ThirdDerivGPpostMeanMatrix{m}(k,j) = ThirdDerivGPpostMean(m); % (1,1) ThirdDerivKernel * a
                                
                                GradGradGradLogLikMatrix{m}(k,j) = std_y *...
                                    ( ( ThirdDerivGPpostMean(m) * ScJacob(m)^3 ) + ( 3 * Q(m) * ScdJacob(m) ) + ...
                                    ( FirstDerivGPpostMean(m) * Scd2Jacob(m) ) );
                                
                            elseif m==k && m~=j
                                
                                ThirdDerivGPpostMeanMatrix{m}(k,j) = ( -Lambda(j,j) * BT(j,:) .* SecondDerivKernel(k,:) ) * a; % (1,1)
                                
                                GradGradGradLogLikMatrix{m}(k,j) = std_y *...
                                    ( ThirdDerivGPpostMeanMatrix{k}(k,j) * ScJacob(k)^2 * ScJacob(j) + SecondDerivGPpostMeanMatrix(k,j) * ScdJacob(k) * ScJacob(j) );
                                                                
                            elseif m==j && m~=k
                                
                                ThirdDerivGPpostMeanMatrix{m}(k,j) = ( -Lambda(j,j) * ( FirstDerivKernel(k,:) + BT(j,:) .* SecondPartialDerivKernel(j,k) ) ) * a; % (1,1)
                                
                                GradGradGradLogLikMatrix{m}(k,j) = std_y *...
                                    ( ThirdDerivGPpostMeanMatrix{j}(k,j) * ScJacob(j)^2 * ScJacob(k) + SecondDerivGPpostMeanMatrix(k,j) * ScJacob(k) * ScdJacob(j) );
                                                                
                            elseif j==k && m~=j
                                
                                ThirdDerivGPpostMeanMatrix{m}(k,j) = ( -Lambda(j,j) * ( FirstDerivKernel(m,:) + BT(j,:) .* SecondPartialDerivKernel(m,j) ) ) * a; % (1,1)
                                
                                GradGradGradLogLikMatrix{m}(k,j) = std_y *...
                                    ( ThirdDerivGPpostMeanMatrix{m}(j,j) * ScJacob(m) * ScJacob(j)^2 + SecondDerivGPpostMeanMatrix(m,j) * ScJacob(m) * ScdJacob(j) );
                                
                            else % m~=k~=j
                                
                                ThirdDerivGPpostMeanMatrix{m}(k,j) = ( -Lambda(j,j) * BT(j,:) .* SecondPartialDerivKernel(m,k) ) * a; % (1,1)
                                
                                GradGradGradLogLikMatrix{m}(k,j) = std_y *...
                                    ( ThirdDerivGPpostMeanMatrix{m}(k,j) * ScJacob(m) * ScJacob(k) * ScJacob(j) );
                                                                
                            end
                            
                            GradGradGradLogLikMatrix{m}(j,k) = GradGradGradLogLikMatrix{m}(k,j); % matrix is symmetric
                            
                        end
                    end
                end
                
            end % grad23_EmInd(2)
            
        end %grad23_EmInd(1)
        
    end %pass
    
end % em_ind

LogPrior = 0;
for i=1:nd
    LogPrior = LogPrior + ( - (log(sqrt(GP_hyperHyper(2*i))) + 0.5*log(2*pi)) - ...
        ((param_sc(i) - GP_hyperHyper(2*i-1))^2)/(2*GP_hyperHyper(2*i)) );
end

GradLogPrior = NaN(numel(param),1);
for i=1:nd
    GradLogPrior(i) = - (param_sc(i) - GP_hyperHyper(2*i-1))/GP_hyperHyper(2*i);
end

if em_ind == 1 && grad23_EmInd(1) == 1
    
    % 2nd derivative
    GradGradLogPrior = NaN(numel(param),1);
    for i=1:nd
        GradGradLogPrior(i) = -1/GP_hyperHyper(2*i);
    end
    GradGradLogPriorMatrix = diag ( GradGradLogPrior ); % and the off-diagonal elements are zero
    
    if grad23_EmInd(2) == 1
        % 3rd derivative

        GradGradGradLogPrior = zeros(numel(param),1);
        
        GradGradGradLogPriorMatrix = cell(nd,1); % contains d matrices
        
        for m=1:nd
            GradGradGradLogPriorMatrix{m} = zeros(nd,nd);
            GradGradGradLogPriorMatrix{m}(m,m) = GradGradGradLogPrior(m);
        end
        
    end % grad23_EmInd(2)
    
end % em_ind && grad23_EmInd(1)

if pass == 1
    
    LogPosterior = LogLik + LogPrior;
    
    GradLogPosterior = GradLogLik + GradLogPrior;
    
    if em_ind == 1 && grad23_EmInd(1) == 1 && phase_ind == 2
        
        GradGradLogPosteriorMatrix = GradGradLogLikMatrix + GradGradLogPriorMatrix;
        
        if grad23_EmInd(2) == 1
            
            GradGradGradLogPosteriorMatrix = cell(nd,1); % contains d matrices
            
            for m=1:nd
                GradGradGradLogPosteriorMatrix{m} = GradGradGradLogLikMatrix{m} + GradGradGradLogPriorMatrix{m};
            end
            
        else
            
            GradGradGradLogPosteriorMatrix = NaN; % not needed
            
        end % grad23_EmInd(2)
        
        FirstSecondGradProd = cell(nd,1);
        
        for k=1:nd
            
            FirstSecondGradProd{k} = zeros(nd,nd);
            
            for j=1:nd
                for i=1:nd
                    FirstSecondGradProd{k}(j,i) = GradGradLogPosteriorMatrix(k,j) * GradLogPosterior(i) + ...
                        GradLogPosterior(j) * GradGradLogPosteriorMatrix(k,i);
                    
                    FirstSecondGradProd{k}(i,j) = FirstSecondGradProd{k}(j,i); % matrix is symmetric
                end
            end
            
        end
        
    else
        % NaNs if phase_ind = 1, for which we do not need 2nd and 3rd derivative
        
        GradGradLogPosteriorMatrix = NaN; % not needed in our code
        
        GradGradGradLogPosteriorMatrix = NaN; % not needed in our code
        
        FirstSecondGradProd = NaN; % not needed in our code
        
    end
    
else % pass = 0
    
    LogPosterior = -10^10; % equivalent to Posterior = 0
    GradLogPosterior = zeros(nd,1);
    
    if em_ind == 1 && grad23_EmInd(1) == 1 && phase_ind == 2
        GradGradLogPosteriorMatrix = zeros(nd,nd);
        if grad23_EmInd(2) == 1
            GradGradGradLogPosteriorMatrix = cell(nd,1); % contains d matrices
            for m=1:nd
                GradGradGradLogPosteriorMatrix{m} = zeros(nd,nd);
            end
        else
            GradGradGradLogPosteriorMatrix = NaN; % not needed
            
        end % grad23_EmInd(2)
        
        FirstSecondGradProd = cell(nd,1); % contains d matrices
        
        for m=1:nd
            FirstSecondGradProd{m} = zeros(nd,nd);
        end
        
    else
        % NaNs if phase_ind = 1, for which we do not need 2nd and 3rd derivative
        
        GradGradLogPosteriorMatrix = NaN; % not needed
        GradGradGradLogPosteriorMatrix = NaN; % not needed
        FirstSecondGradProd = NaN; % not needed in our code
        
    end % grad23_EmInd(1)
    
end % pass

end