% An example of running the Geweke consistency check for DA-GPNUTS in the
% sampling phase 
clear; close all;

% Add necesary paths, e.g. to GPstuff
GPpath = genpath('GPstuff-4.7');
addpath(GPpath); % add the folder and its subfolders to the search path
addpath('CommonFunctions');
addpath('Results')

ndatasets = 200; % no of data sets

delete(gcp('nocreate'))
parpool('local', 20)

par_unbound_em = cell(ndatasets,1); % parameter samples
par_orig_sim = cell(ndatasets,1);
LogLik = cell(ndatasets,1);
logpost_orig_sim = cell(ndatasets,1);
logpost_unbound_em = cell(ndatasets,1);
gradlogpost_unbound_em = cell(ndatasets,1);

parfor m=1:ndatasets
    
    % Generate a data set with parameter values drawn from the prior
    % distribution
    n = 50; % no of data points
    x = linspace(0,2*pi,n);
    GP_hyperHyper = [log(4), 0.02, log(1), 0.01, log(0.05), 0.05]; % hyperpriors
    mu = [GP_hyperHyper(1),GP_hyperHyper(3),GP_hyperHyper(5)];
    sigma = sqrt([GP_hyperHyper(2),GP_hyperHyper(4),GP_hyperHyper(6)]);
    theta{m} = lognrnd(mu,sigma); 
    A_true = theta{m}(1); B_true = theta{m}(2); C_true = theta{m}(3);
    
    fx = A_true*sin(B_true*(x+C_true)); % clean data
    
    sigma2 = 0.12; % noise variance
    Cov = sigma2*eye(n,n);
    
    res = mvnrnd(zeros(n,1), Cov, 1);
    
    y =  fx + res; % noisy data
    
    nd = 3; % parameter dimensionality
    
    % Compact support for the emulator
    l = [1, 0.5, 0.01];
    u = [9, 1.7,  0.2];
    
    % Parameter scaling for emulation
    sc = [10, 10, 10];
    
    % Initial design: draw points from a Sobol sequence
    X = sobolset(nd, 'Skip',1.4e4,'Leap',0.6e13);
    
    A_vec = l(1) + (u(1)-l(1)) * X(:,1);
    B_vec = l(2) + (u(2)-l(2)) * X(:,2);
    C_vec = l(3) + (u(3)-l(3)) * X(:,3);
    
    par = [A_vec, B_vec, C_vec]./sc;
    
    % Run simulator to obtain log lik for training points
    loglik = NaN(size(par, 1),1);
    for i=1:size(par, 1)
        fx = A_vec(i) * sin(B_vec(i)*(x+C_vec(i)));
        loglik(i) = -n/2*log(sigma2)-n/2*log(2*pi) - sum((y-fx).^2)/(2*sigma2);
    end
    
    k = 400; % no of points we want to keep to fit the GP regression
    temp = sort(loglik, 'descend');
    T_ll = temp(k); % the threshold is the lowest loglik value out of the k values we keep to fit the GP regression
    
    I_ll = loglik>T_ll;
    x_regr = par(I_ll,:); y_regr = loglik(I_ll);
    
    mean_y = mean(y_regr);
    std_y = std(y_regr);
    
    loglik_max = max(max(loglik(loglik~=-10^10)));
    loglik_min = min(min(loglik(loglik~=-10^10)));
    
    y_regr = (y_regr-mean_y)./std_y; % mean 0 and std 1 of of y
    
    % Build GP model (loglik emulator)        
    [gp_regr, nlml_regr] = GPmodel(x_regr, y_regr, [1 0.01 0.01 0.01 10^(-5)]);
    
    [w,s] = gp_pak(gp_regr);
    disp(exp(w))
    
    %Make predictions using gp_regr
    [E, Var] = gp_pred(gp_regr, x_regr, y_regr, x_regr);
    figure(1); clf(1); plot(E, y_regr, '.');
    hold on; plot(E,E,'-r')
    xlabel('Train data'); ylabel('Predictions')
    
    %% Phase 1 of the GPHMC algorithm
    % (Run HMC)
    
    phase_ind = 1; % exploratory phase
    
    do_nuts = 0;
    
    do_DA = 1; % do delayed acceptance
    
    x_regr_refitted = x_regr;
    y_regr_refitted = y_regr;
    gp_regr_refitted = gp_regr;
    
    % Obtain the covariance matrix and find its inverse to pass on by reference
    % to the functions as to avoid the repeated matrix inversion
    [~,Cov] = gp_trcov(gp_regr_refitted, x_regr_refitted);
    Lcov = chol(Cov,'lower');
    invL = Lcov\eye(size(y_regr_refitted,1),size(y_regr_refitted,1)); % inverse of Lcov
    % Cov = Lcov'Lcov; Cov^(-1) = (Lcov'Lcov)^(-1) = (Lcov')^(-1)(Lcov^(-1)) = (Lcov^(-1))'(Lcov^(-1))
    % (Lcov')^(-1) = (Lcov^(-1))', inverse of transpose is transpose of inverse for a triangular matrix
    invLref = largematrix; % create an object to pass the inverse of Lcov as an argument by reference (if this hasn't been done before)
    invLref.array = invL;
    
    nSamples = 400; % no of HMC samples
    
    p = NaN(nSamples,nd); % theta parameter samples
    loglik = NaN(nSamples,1);
    
    % Initialise
    p(1,:) = log(x_regr(y_regr.*std_y+mean_y==max(y_regr.*std_y+mean_y),:).*sc);% this is unbounded variable
    
    em_ind=0; % emulation indicator (0: simulator used)
    grad23_EmInd = [NaN NaN];
    [LogPosterior_sim, ~, ~, ~, ~, loglik(1)] = ...
        Sin_HMCDerivPosterior_all(p(1,:), x, y, sigma2, GP_hyperHyper, ...
        gp_regr_refitted, x_regr_refitted, y_regr_refitted, sc, nd, ...
        phase_ind, em_ind, grad23_EmInd, mean_y, std_y, do_nuts, invLref);
    
    em_ind=1;  % emulation indicator (2: emulator used)
    grad23_EmInd = [0 0]; % do not calculate 2nd and 3rd order derivatives 
    % of emulator log posterior
    [LogPosterior_em,GradLogPost_em] = Sin_HMCDerivPosterior_all(p(1,:), ...
        x, y, sigma2, GP_hyperHyper, ...
        gp_regr_refitted, x_regr_refitted, y_regr_refitted, sc, nd, ...
        phase_ind, em_ind, grad23_EmInd, mean_y, std_y, do_nuts, invLref);
    
    acc = 0; % acceptance rate
    
    M = eye(nd,nd); % mass matrix
    
    epsilon = 0.005; L = 20;
    % Enter HMC loop to draw nSamples
    for i=2:nSamples
        [p(i,:),LogPosterior_sim,LogPosterior_em,GradLogPost_em, loglik(i),...
            noODE_counter, gp_regr_refitted, x_regr_refitted, ...
            y_regr_refitted,mean_y,std_y,invLref] = ...
            HMC_Sin_MoreEfficient(p(i-1,:), sigma2, epsilon, L, gp_regr_refitted, ...
            x_regr_refitted, y_regr_refitted, sc, nd, phase_ind, x, y, ...
            GP_hyperHyper,LogPosterior_sim, LogPosterior_em, ...
            GradLogPost_em, loglik(i-1), mean_y, std_y, do_nuts, M, invLref, do_DA);
        
        if all(p(i,:) ~= p(i-1,:)) % we've just accepted the new point
            acc = acc + 1;
            
            param = exp(p(i,:)); % parameters on original scale
            param_em = param./sc; % parameters used in emulation
            
            if x_regr_refitted(end,:)~=param_em % i.e. if we haven't already
                % added this point as a consequence of sqrt(Var)>=3
                x_regr_refitted(end+1,:) = param_em;
                y_regr_refitted = y_regr_refitted .* std_y + mean_y; % bring on original scale
                y_regr_refitted(end+1) = loglik(i); % because loglik is on original scale
                
                mean_y = mean(y_regr_refitted);
                std_y = std(y_regr_refitted);
                y_regr_refitted = (y_regr_refitted - mean_y)./std_y;
                
                gp_regr_refitted = gp_optim(gp_regr_refitted,x_regr_refitted,y_regr_refitted);
                
                % Update cov matrix here to pass on by reference
                [~,Cov] = gp_trcov(gp_regr_refitted, x_regr_refitted);
                L = chol(Cov,'lower');
                invL = L\eye(size(y_regr_refitted,1),size(y_regr_refitted,1)); % inverse of L
                % Cov = L'L; Cov^(-1) = (L'L)^(-1) = (L')^(-1)(L^(-1)) = (L^(-1))'(L^(-1))
                % (L')^(-1) = (L^(-1))', inverse of transpose is transpose of inverse for a triangular matrix
                %invLref = largematrix; % create an object to pass the inverse of L as an argument by reference
                invLref.array = invL;
                
            end
            
        end
        
    end
    
    figure(1);clf(1)
    subplot(2,3,1);plot(1:nSamples,exp(p(:,1)))
    subplot(2,3,2);plot(1:nSamples,exp(p(:,2)))
    subplot(2,3,3);plot(1:nSamples,exp(p(:,3)))
        
    y_regr_refitted = y_regr_refitted .* std_y + mean_y;
    k = 400; % no of points we want to keep to fit the GP regression
    temp = sort(y_regr_refitted, 'descend');
    T_ll = temp(k); % the threshold is the lowest loglik value out of the k values we keep to fit the GP regression
    I_ll = find(y_regr_refitted > T_ll);
    y_regr_refitted = y_regr_refitted(I_ll);
    mean_y = mean(y_regr_refitted);
    std_y = std(y_regr_refitted);
    
    y_regr_refitted = (y_regr_refitted - mean_y)./std_y;
    x_regr_refitted = x_regr_refitted(I_ll,:);
    
    % Refit GP with burnin phase removed
    % Use this GP in the sampling phase
    gp_regr_refitted = gp_optim(gp_regr_refitted,x_regr_refitted,y_regr_refitted);
    
    % Obtain the covariance matrix and find its inverse to pass on by reference
    % to the functions as to avoid the repeated matrix inversion
    [~,Cov] = gp_trcov(gp_regr_refitted, x_regr_refitted);
    L = chol(Cov,'lower');
    invL = L\eye(size(y_regr_refitted,1),size(y_regr_refitted,1)); % inverse of L
    % Cov = L'L; Cov^(-1) = (L'L)^(-1) = (L')^(-1)(L^(-1)) = (L^(-1))'(L^(-1))
    % (L')^(-1) = (L^(-1))', inverse of transpose is transpose of inverse for a triangular matrix
    %invLref = largematrix; % create an object to pass the inverse of L as an argument by reference
    invLref.array = invL;
    
    %% Phase 2 (Run NUTS)
    
    do_nuts = 1; % do NUTS in the sampling phase
    
    phase_ind = 2; % sampling phase
    nSamples = 5000; n_burnin=50;
    
    % Initialise
    p0 = log(x_regr_refitted(1,:).*sc); % unbounded
    p0 = p0';
    par_unbound_em{m}(:,1) = p0;% this is unbounded variable
    
    max_tree_depth = 10;

    delta = 0.8;
    
    em_ind=1; grad23_EmInd = [0 0];
    f = @(p_unbound)Sin_HMCDerivPosterior_all(p_unbound, x, y, ...
        sigma2, GP_hyperHyper, gp_regr_refitted, x_regr_refitted, ...
        y_regr_refitted, sc, nd, phase_ind, em_ind, ...
        grad23_EmInd, mean_y, std_y, do_nuts, invLref);
    
    % Choose a reasonable first epsilon by a simple heuristic.
    em_ind=1; grad23_EmInd = [0 0];
    [logp0, logpgrad0] = Sin_HMCDerivPosterior_all(p0, x, y, ...
        sigma2, GP_hyperHyper, gp_regr_refitted, x_regr_refitted, ...
        y_regr_refitted, sc, nd, phase_ind, em_ind, ...
        grad23_EmInd, mean_y, std_y, do_nuts, invLref);
    
    [epsilon0, ~] = find_reasonable_epsilon(p0, logpgrad0, logp0, f);
    
    [par_unbound_em{m}(:,1), alpha_ave, nfevals_total, ...
        logpost_unbound_em{m}(1), gradlogpost_unbound_em{m}(:,1)] = ...
        NUTS(f, epsilon0, p0, logp0, logpgrad0, max_tree_depth);
    
    % Parameters for the dual averaging algorithm.
    gamma = 0.05; t0 = 10; kappa = 0.75;
    mu = log(10 * epsilon0); epsilonbar = 1; Hbar = 0;
    davg_par = [gamma, t0, kappa, mu, epsilonbar, Hbar];
    
    [epsilon(1), Hbar, epsilonbar] = DualAveraging(1, delta, alpha_ave, davg_par);
    davg_par = [gamma, t0, kappa, mu, epsilonbar, Hbar]; % update param for dual avg
    
    par_orig_sim{m}(:,1) = exp(par_unbound_em{m}(:,1));
    
    em_ind = 0; grad23_EmInd = [NaN NaN];
    [logpost_orig_sim{m}(1), ~, ~, ~, ~, LogLik{m}(1)] = ...
        Sin_HMCDerivPosterior_all(par_unbound_em{m}(:,1), x, y, ...
        sigma2, GP_hyperHyper, gp_regr_refitted, x_regr_refitted, ...
        y_regr_refitted, sc, nd, phase_ind, em_ind, ...
        grad23_EmInd, mean_y, std_y, do_nuts, invLref);
    
    
    acc = 0;
    
    for i = 2:nSamples+n_burnin
        
        % Redefine f for the newly drawn s2 to be used in the next NUTS iteration
        em_ind=1; grad23_EmInd = [0 0];
        f = @(p_unbound)Sin_HMCDerivPosterior_all(p_unbound, x, y, ...
            sigma2, GP_hyperHyper, gp_regr_refitted, x_regr_refitted, ...
            y_regr_refitted, sc, nd, phase_ind, em_ind, ...
            grad23_EmInd, mean_y, std_y, do_nuts, invLref);
        
        [par_unbound_em{m}(:,i), alpha_ave, nfevals, ...
            logpost_unbound_em{m}(i), gradlogpost_unbound_em{m}(:,i)] = ...
            NUTS(f, epsilon(i-1), par_unbound_em{m}(:,i-1), ...
            logpost_unbound_em{m}(i-1), gradlogpost_unbound_em{m}(:,i-1), ...
            max_tree_depth);
        
        % Adapt epsilon using dual average algorithm for par_unbound_em(:,i)
        % regardless of whether we have accepted or not
        if i <= n_burnin % we adapt epsilon within the burnin phase
            
            [epsilon(i), Hbar, epsilonbar] = ...
                DualAveraging(i, delta, alpha_ave, davg_par);
            davg_par = [gamma, t0, kappa, mu, epsilonbar, Hbar]; % update param for dual avg
        else
            
            epsilon(i) = epsilonbar; % use last adapted epsilonbar if we've stopped adapting
        end
        
        if all(par_unbound_em{m}(:,i) == par_unbound_em{m}(:,i-1)) % we've rejected
            %disp('reject in stage 1')
            par_orig_sim{m}(:,i) = par_orig_sim{m}(:,i-1);
            LogLik{m}(i) = LogLik{m}(i-1);
            logpost_orig_sim{m}(i) = logpost_orig_sim{m}(i-1);
            
        else
            
            %disp('accept in stage 1')
            em_ind = 0; grad23_EmInd = [NaN NaN];
            [LogPosterior_sim_end, ~, ~, ~, ~, LogLik_sim_end] = ...
                Sin_HMCDerivPosterior_all(par_unbound_em{m}(:,i),...
                x, y, sigma2, GP_hyperHyper, gp_regr_refitted, ...
                x_regr_refitted, y_regr_refitted, sc, nd, ...
                phase_ind, em_ind, grad23_EmInd, mean_y, std_y, do_nuts, invLref);
            
            LogPosterior_sim_begin = logpost_orig_sim{m}(i-1);
            LogPosterior_em_begin = logpost_unbound_em{m}(i-1);
            LogPosterior_em_end = logpost_unbound_em{m}(i);
            
            r2 = LogPosterior_sim_end - LogPosterior_sim_begin + ...
                LogPosterior_em_begin - LogPosterior_em_end;
            
            if r2 > 0 || (r2 > log(rand)) % accept at 2nd stage
                %disp('accept in stage 2')
                acc = acc + 1;
                
                par_orig_sim{m}(:,i) = exp(par_unbound_em{m}(:,i));
                LogLik{m}(i) = LogLik_sim_end;
                logpost_orig_sim{m}(i) = LogPosterior_sim_end;
                
            else % reject at 2nd stage
                %disp('reject in stage 2')
                par_orig_sim{m}(:,i) = par_orig_sim{m}(:,i-1);
                par_unbound_em{m}(:,i) = par_unbound_em{m}(:,i-1)
                LogLik{m}(i) = LogLik{m}(i-1);
                logpost_orig_sim{m}(i) = logpost_orig_sim{m}(i-1);
                logpost_unbound_em{m}(i) = logpost_unbound_em{m}(i-1); % update this to the old value if reject in 2
                gradlogpost_unbound_em{m}(:,i) = gradlogpost_unbound_em{m}(:,i-1); % update this to the old value if reject in 2
                
            end
            
        end
        
    end
    
    
    saveGeweke(sprintf('DAGPNUTSsin3d_run %d.mat', m), ...
        par_unbound_em{m}, par_orig_sim{m}, LogLik{m}, logpost_orig_sim{m}, ...
        logpost_unbound_em{m}, gradlogpost_unbound_em{m}, theta{m})
    
end

exit;

nd=3; nSamples = 5000;
for i=1:ndatasets
    for j=1:nd
        post_sample(j,i) = (p_sample{i}(end,j));
    end
end

for i=1:ndatasets
    for j=1:nd
        prior(j,i) = theta{i}(j);
    end
end

figure;qqplot(prior(1,:),exp(post_sample(1,:)));hold on;line([min(prior(1,:)) max(prior(1,:))],[min(prior(1,:)) max(prior(1,:))],'Color','red','LineStyle','--', 'Linewidth',3)
figure;qqplot(prior(2,:),exp(post_sample(2,:)));hold on;line([min(prior(2,:)) max(prior(2,:))],[min(prior(2,:)) max(prior(2,:))],'Color','red','LineStyle','--', 'Linewidth',3)
figure;qqplot(prior(3,:),exp(post_sample(3,:)));hold on;line([min(prior(3,:)) max(prior(3,:))],[min(prior(3,:)) max(prior(3,:))],'Color','red','LineStyle','--', 'Linewidth',3)