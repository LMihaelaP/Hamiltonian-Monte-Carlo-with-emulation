function saveGeweke(fname, p_sample, par_orig_sim, LogLik, ...
    logpost_orig_sim, logpost_unbound_em, gradlogpost_unbound_em, prior)

FolderDestination = 'GewekeTests/DAGPNUTS';
matfile = fullfile(FolderDestination,fname);

save(matfile, 'p_sample', 'par_orig_sim', 'LogLik', 'logpost_orig_sim', ...
    'logpost_unbound_em', 'gradlogpost_unbound_em', 'prior')
end
