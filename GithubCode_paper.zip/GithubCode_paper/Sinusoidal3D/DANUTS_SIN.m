% Run DA-GP-NUTS with application to the 3D sinusoidal problem
clear; close all;

% Add necesary paths, e.g. to GPstuff
GPpath = genpath('GPstuff-4.7');
addpath(GPpath); % add the folder and its subfolders to the search path
addpath('CommonFunctions');
addpath('Results')

nds = 10; % no of data sets

ntimeit = 3;% no of times we time the programme in the sampling phase

% Folder where the results will be saved
ResultsDestination = 'Results';

for ids = 1:nds
    
    % Load the initial + exploratory phase (run in the BayesianOptimisation_DAHMC_* script)
    load(sprintf('Results/PaperResults_GPHMC_Exploratory_SIN_dataset %d.mat', ids));
    
    %% Sampling phase
    phase_ind = 2; % 'sampling' phase in Rasmussen's paper
    
    do_nuts = 1; % do nuts
    
    % time the algorithm ntimeit times for every data set
    for it = 1:ntimeit
        
        % Set NUTS parameters
        delta = 0.8; % desired acc prob
        max_tree_depth = 10; % maximum depth of the tree in NUTS
        
        % The number of samples in the sampling phase
        nSamples = 2000; % no of samples in sampling phase
        nburnin = 100; % no of samples in burnin phase
        
        nrun = 10; % run 10 chains in parallel
        acc = zeros(nrun,1); % acceptance rates for every chain
        
        par_unbound_em = cell(nrun,1); % unbounded par samples from the sampling phase for the emulator
        logpost_unbound_em = cell(nrun,1); % log posterior evaluated at each par_unbound for the emulator
        gradlogpost_unbound_em = cell(nrun,1); % gradlogpost_unbound is gradient of log posterior
        par_orig_sim = cell(nrun,1); % orig parameter samples from the sampling phase for the simulator
        LogLik = cell(nrun,1); % sum-of-square samples from the sampling phase for the simulator
        logpost_orig_sim = cell(nrun,1); % log post evaluated at each par_orig using the simulator
        epsilon = cell(nrun,1); % list of epsilons along the mcmc for every chain
        
        delete(gcp('nocreate'))
        parpool('local', nrun)
        
        % Store cpu times for every run and average the at the end
        initime = NaN(nrun,1);
        fintime = NaN(nrun,1);
        
        noODE_counter_proc = zeros(nrun,1); % count no of ODE evaluations in the processing (sampling) phase
        
        p1 = Par(nd);
        
        parfor j = 1:nrun
            
            noODE_counter_run = 0;
            
            p0 = log(x_regr_refitted(j,:).*sc); % unbounded
            p0 = p0';
            
            em_ind=1; grad23_EmInd = [0 0];
            f = @(p_unbound)Sin_HMCDerivPosterior_all(p_unbound, x, y, ...
                sigma2, GP_hyperHyper, gp_regr_refitted, x_regr_refitted, ...
                y_regr_refitted, sc, nd, phase_ind, em_ind, ...
                grad23_EmInd, mean_y, std_y, do_nuts, invLref);
            
            % Choose a reasonable first epsilon by a simple heuristic.
            em_ind=1; grad23_EmInd = [0 0];
            [logp0, logpgrad0] = Sin_HMCDerivPosterior_all(p0, x, y, ...
                sigma2, GP_hyperHyper, gp_regr_refitted, x_regr_refitted, ...
                y_regr_refitted, sc, nd, phase_ind, em_ind, ...
                grad23_EmInd, mean_y, std_y, do_nuts, invLref);
            
            [epsilon0, ~] = find_reasonable_epsilon(p0, logpgrad0, logp0, f);
            
            [par_unbound_em{j}(:,1), alpha_ave, nfevals_total, ...
                logpost_unbound_em{j}(1), gradlogpost_unbound_em{j}(:,1)] = ...
                NUTS(f, epsilon0, p0, logp0, logpgrad0, max_tree_depth);
            
            % Parameters for the dual averaging algorithm.
            gamma = 0.05; t0 = 10; kappa = 0.75;
            mu = log(10 * epsilon0); epsilonbar = 1; Hbar = 0;
            davg_par = [gamma, t0, kappa, mu, epsilonbar, Hbar];
            
            [epsilon{j}(1), Hbar, epsilonbar] = DualAveraging(1, delta, alpha_ave, davg_par);
            davg_par = [gamma, t0, kappa, mu, epsilonbar, Hbar]; % update param for dual avg
            
            par_orig_sim{j}(:,1) = exp(par_unbound_em{j}(:,1));
            
            em_ind = 0; grad23_EmInd = [NaN NaN];
            [logpost_orig_sim{j}(1), ~, ~, ~, ~, LogLik{j}(1)] = ...
                Sin_HMCDerivPosterior_all(par_unbound_em{j}(:,1), x, y, ...
                sigma2, GP_hyperHyper, gp_regr_refitted, x_regr_refitted, ...
                y_regr_refitted, sc, nd, phase_ind, em_ind, ...
                grad23_EmInd, mean_y, std_y, do_nuts, invLref);
            
            for i = 2:nSamples+nburnin
                
                if i == nburnin + 1 % start measuring after the burnin
                    initime(j) = cputime;
                    Par.tic;
                end
                
                [par_unbound_em{j}(:,i), alpha_ave, nfevals, ...
                    logpost_unbound_em{j}(i), gradlogpost_unbound_em{j}(:,i)] = ...
                    NUTS(f, epsilon{j}(i-1), par_unbound_em{j}(:,i-1), ...
                    logpost_unbound_em{j}(i-1), gradlogpost_unbound_em{j}(:,i-1), ...
                    max_tree_depth);
                
                % Adapt epsilon using dual average algorithm for par_unbound_em(:,i)
                % regardless of whether we have accepted or not
                if i <= nburnin % we adapt epsilon within the burnin phase
                    
                    [epsilon{j}(i), Hbar, epsilonbar] = ...
                        DualAveraging(i, delta, alpha_ave, davg_par);
                    davg_par = [gamma, t0, kappa, mu, epsilonbar, Hbar]; % update param for dual avg
                else
                    
                    epsilon{j}(i) = epsilonbar; % use last adapted epsilonbar if we've stopped adapting
                end
                
                if all(par_unbound_em{j}(:,i) == par_unbound_em{j}(:,i-1)) % we've rejected
                    %disp('reject in stage 1')
                    par_orig_sim{j}(:,i) = par_orig_sim{j}(:,i-1);
                    LogLik{j}(i) = LogLik{j}(i-1);
                    logpost_orig_sim{j}(i) = logpost_orig_sim{j}(i-1);
                    
                else
                    
                    %disp('accept in stage 1')
                    % next calculate acc rate in stage 2 using the simulator in an MH step
                    em_ind = 0; grad23_EmInd = [NaN NaN];
                    [LogPosterior_sim_end, ~, ~, ~, ~, LogLik_sim_end] = ...
                        Sin_HMCDerivPosterior_all(par_unbound_em{j}(:,i),...
                        x, y, sigma2, GP_hyperHyper, gp_regr_refitted, ...
                        x_regr_refitted, y_regr_refitted, sc, nd, phase_ind, ...
                        em_ind, grad23_EmInd, mean_y, std_y, do_nuts, invLref);
                    
                    if i > nburnin % start counting in the sampling phase
                        noODE_counter_run = noODE_counter_run + 1;
                    end
                    
                    LogPosterior_sim_begin = logpost_orig_sim{j}(i-1);
                    LogPosterior_em_begin = logpost_unbound_em{j}(i-1);
                    LogPosterior_em_end = logpost_unbound_em{j}(i);
                    
                    r2 = LogPosterior_sim_end - LogPosterior_sim_begin + ...
                        LogPosterior_em_begin - LogPosterior_em_end;
                    
                    if r2 > 0 || (r2 > log(rand)) % accept at 2nd stage
                        %disp('accept in stage 2')
                        acc(j) = acc(j) + 1;
                        
                        par_orig_sim{j}(:,i) = exp(par_unbound_em{j}(:,i));
                        LogLik{j}(i) = LogLik_sim_end;
                        logpost_orig_sim{j}(i) = LogPosterior_sim_end;
                        
                    else % reject at 2nd stage
                        %disp('reject in stage 2')
                        par_orig_sim{j}(:,i) = par_orig_sim{j}(:,i-1);
                        par_unbound_em{j}(:,i) = par_unbound_em{j}(:,i-1);
                        LogLik{j}(i) = LogLik{j}(i-1);
                        logpost_orig_sim{j}(i) = logpost_orig_sim{j}(i-1);
                        logpost_unbound_em{j}(i) = logpost_unbound_em{j}(i-1); % update this to the old value if reject in 2
                        gradlogpost_unbound_em{j}(:,i) = gradlogpost_unbound_em{j}(:,i-1); % update this to the old value if reject in 2
                        
                    end
                    
                end
                
            end
            
            noODE_counter_proc(j) = noODE_counter_proc(j) + noODE_counter_run;
            
            p1(j) = Par.toc;
            
            fintime(j) = cputime;
            
        end %parfor
        
        CPUtime_DAGPNUTS_sampling = fintime-initime;
        
        ElapsedTime_DAGPNUTS_sampling = NaN(nd,1);
        
        for j=1:nrun
            ElapsedTime_DAGPNUTS_sampling(j) = p1(1,j).ItStop - p1(1,j).ItStart;
        end
        
        fname = sprintf('Sin_dataset %d_DAGPNUTS_sampling %d.mat', ids, it);
        matfile = fullfile(ResultsDestination,fname);
        save(matfile)
        
    end % ntimeit
    
end % ids

exit;