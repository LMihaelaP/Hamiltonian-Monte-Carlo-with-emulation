This folder contains the Matlab scripts to run Hamiltonian/Lagrangian Monte Carlo algorithms for the sinusoidal model.

- Data generation, as well as initial and exploratory phase for the GP-HMC, and sampling phase with DA-GP-HMC (with Bayesian Optimisation for optimisation of tuning parameters): BayesianOptimisation_DAHMC_SIN.m (this should be run first)

- Sampling phase with noDA-GP-HMC (with optimisation of tuning parameters performed in DA-GP-HMC): BayesianOptimisation_noDAHMC_SIN.m

- Sampling phase with noDA-GP-RMHMC (with Bayesian Optimisation for optimisation of tuning parameters): Run_BayesianOptimisation_noDARMHMC_SIN.m (this should be run before the DA-GP-RMHMC to obtain the optimum tuning parameters)

- Sampling phase with DA-GP-RMHMC (with optimisation of tuning parameters performed in noDA-GP-RMHMC): Run_BayesianOptimisation_DARMHMC_SIN.m

- Sampling phase with noDA-GP-LDMC (with Bayesian Optimisation for optimisation of tuning parameters): Run_BayesianOptimisation_noDALDMC_SIN.m (this should be run before the DA-GP-LDMC to obtain the optimum tuning parameters)

- Sampling phase with DA-GP-LDMC (with optimisation of tuning parameters performed in noDA-GP-LDMC): Run_BayesianOptimisation_DALDMC_SIN.m