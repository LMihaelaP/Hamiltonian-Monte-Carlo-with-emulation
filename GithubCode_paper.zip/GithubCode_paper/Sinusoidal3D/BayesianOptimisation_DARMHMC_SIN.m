% Run DA-GP-RMHMC with Bayesian Optimisation for the number of leapfrog steps
% and the step size with application to the 3D sinusoidal problem
clear; close all;

% Add necesary paths, e.g. to GPstuff
GPpath = genpath('GPstuff-4.7');
addpath(GPpath); % add the folder and its subfolders to the search path
addpath('CommonFunctions');
addpath('Results')

nds = 10; % no of data sets

ntimeit = 3;% no of times we time the programme in the sampling phase

% Folder where the results will be saved
ResultsDestination = 'Results';

for ids = 1:nds
    
    % Load the workspace containing the initial + exploratory phase (run in the BayesianOptimisation_DAHMC_* script) and the optimum tuning parameters (run in BayesianOptimisation_noDARMHMC_*)
    load(sprintf('Results/BO_RMHMC_FindBestEpsL_SIN_dataset %d.mat', ids));
    
    %%
    % Now run RMHMC with the 'best' epsilon and L identified (3 times) for
    % every data set
    % Eps and L used are the same for DA and noDA and across different runs for
    % DA and noDA
    
    do_DA = 1; % do delayed acceptance
    
    do_nuts = 0;
    
    for it = 1:ntimeit
        
        nSamples = 2000; % no of sampling phase samples
        nburnin = 100; % no of burnin phase samples
        L = bestL; % no of steps in leapfrog scheme
        epsilon = bestEps; % step size in leapfrog scheme
        phase_ind = 2; % phase index in Rasmussen's paper
        
        nrun = 10; % run 10 chains in parallel
        acc = zeros(nrun,1); % acceptance rate for every chain
        
        p_sample = cell(nrun,1); % parameter samples from the sampling phase
        LogLik_sample = cell(nrun,1); % sigma2 samples from the sampling phase
        
        noODE_counter_proc = zeros(nrun,1); % count no of ODE evaluations in the processing (sampling) phase
        
        delete(gcp('nocreate'))
        parpool('local', nrun)
        
        % Store cpu times for every run and average the at the end
        initime = NaN(nrun,1);
        fintime = NaN(nrun,1);
        
        p1 = Par(nd);
        
        % Run 10 chains in parallel from different initialisations and different
        % random seed generators
        
        
        parfor j=1:nrun
            
            noODE_counter_run = 0;
            
            % Initialise
            p0 = x_regr_refitted(5*j-1,:) .* sc; % original scale
            p_sample{j}(1,:) = log(p0); % unbounded
            
            em_ind = 0; grad23_EmInd = [NaN NaN];
            [LogPosterior_sim, ~, ~, ~, ~, LogLik_sample{j}(1)] = ...
                Sin_HMCDerivPosterior_all(p_sample{j}(1,:), x, y, sigma2, ...
                GP_hyperHyper, gp_regr_refitted, x_regr_refitted, ...
                y_regr_refitted, sc, nd, phase_ind, em_ind, ...
                grad23_EmInd, mean_y, std_y, do_nuts, invLref);
            
            em_ind = 1; grad23_EmInd = [1 1];
            [LogPosterior_em,GradLogPost_em,GradGradLogPost_em,...
                GradGradGradLogPost_em, ~, ~, FirstSecondGradProd_em] = ...
                Sin_HMCDerivPosterior_all(p_sample{j}(1,:), ...
                x, y, sigma2, GP_hyperHyper, gp_regr_refitted, ...
                x_regr_refitted, y_regr_refitted, sc, nd, phase_ind, ...
                em_ind, grad23_EmInd, mean_y, std_y, do_nuts, invLref);
            
            % Enter RMHMC loop to draw nSamples
            for i=2:nSamples+nburnin
                
                if i == nburnin + 1 % start measuring after the burnin
                    initime(j) = cputime;
                    Par.tic;
                end
                
                [p_sample{j}(i,:),LogPosterior_sim,LogPosterior_em,...
                    GradLogPost_em,GradGradLogPost_em,GradGradGradLogPost_em, ...
                    LogLik_sample{j}(i), FirstSecondGradProd_em, no_counter_iter] = ...
                    RMHMC_sin(p_sample{j}(i-1,:), sigma2, ...
                    epsilon, ceil(rand*L), gp_regr_refitted, x_regr_refitted, ...
                    y_regr_refitted, sc, nd, phase_ind, x, y, ...
                    GP_hyperHyper, LogPosterior_sim, LogPosterior_em, ...
                    GradLogPost_em, GradGradLogPost_em, ...
                    GradGradGradLogPost_em, LogLik_sample{j}(i-1), ...
                    mean_y, std_y, do_nuts, invLref, do_DA, ...
                    NumOfNewtonSteps, FirstSecondGradProd_em);
                
                if i > nburnin % start counting in the sampling phase
                    noODE_counter_run = noODE_counter_run + no_counter_iter;
                end
                
                if all(p_sample{j}(i,:) ~= p_sample{j}(i-1,:))
                    % we've just accepted the new point
                    acc(j) = acc(j) + 1;
                end
                
            end
            
            noODE_counter_proc(j) = noODE_counter_proc(j) + noODE_counter_run;
            
            p1(j) = Par.toc;
            
            fintime(j) = cputime;
            
        end % parfor
        
        CPUtime_BO_DAGPRMHMC_sampling = fintime-initime;
        
        ElapsedTime_BO_DAGPRMHMC_sampling = NaN(nd,1);
        
        for j=1:nrun
            ElapsedTime_BO_DAGPRMHMC_sampling(j) = p1(1,j).ItStop - p1(1,j).ItStart;
        end
        
        fname = sprintf('Sin_dataset %d_BO_DAGPRMHMC_sampling %d.mat', ids, it);
        matfile = fullfile(ResultsDestination,fname);
        save(matfile)
        
    end % ntimeit
    
end % nds

exit;