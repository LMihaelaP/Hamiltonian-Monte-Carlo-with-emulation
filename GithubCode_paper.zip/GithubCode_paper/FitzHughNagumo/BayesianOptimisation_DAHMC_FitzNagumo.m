% Run DA-GP-HMC with Bayesian Optimisation for the number of leapfrog steps
% and the step size with application to the FitzHugh-Nagumo problem
clear; close all;

% Add necesary paths, e.g. to GPstuff
GPpath = genpath('GPstuff-4.7');
addpath(GPpath); % add the folder and its subfolders to the search path
addpath('CommonFunctions');
addpath('Results')

nds = 10; % no of data sets

ntimeit = 3;% no of times we time the programme in the sampling phase

% Folder where the results will be saved
ResultsDestination = 'Results';

for ids = 1:nds
    
	%% Run the initial design phase of the GPHMC algorithm
    if 1
        
        % Generate the data
        ns = 2; % no of species
        nd = 3; % total no of parameters without the error variance
        
        % True parameters
        % ODE parameters
        gamma = 3; alpha = 0.2; beta = 0.2;
        % initial values for the species
        V0 = -1; R0 = 1;
        extra_p = [V0, R0];
        
        % noise variance (different for each species)
        sigma2_true = [0.25 0.16];
        
        param_true = [gamma, alpha, beta, sigma2_true];
        
        tspan = [0 20]; % time span
        
        n = 100; % no of time points the time series will have {< size(y,1)}
        time = linspace(tspan(1),tspan(end),n); time = time';
        
        options = odeset('RelTol',1e-6,'AbsTol',1e-6);
        % stable
        [~,clean_data] = ode15s( @(t,y) SolveODEs_FitzHughNagumo(t, y, param_true(1:3)), time, [V0 R0], options );
        
        % Get noisy real data
        noisy_data = NaN(n,ns);
        for i=1:ns
            C = sigma2_true(i)*eye(n,n);
            res = mvnrnd(zeros(n,1), C, 1); res = res';
            noisy_data(:,i) = clean_data(:,i) + res;
        end
        
        trueData = noisy_data;
        
        % compart support for the emulator
        l = [1, 1e-03, 1e-03];
        u = [4, 1, 1];
        
        % Parameter scaling for emulation
        sc = [10, 1, 1];
        
        X = sobolset(nd, 'Skip',1.4e4,'Leap',0.06e14);
        
        par = NaN(size(X,1),nd);
        for i=1:nd
            par(:,i) = l(i) + (u(i)-l(i)) * X(:,i);
        end
        
        par = par./sc;
        
        noODE_counter_InitExpl = 0; % count no of ODE evaluations in the initial & exploratory phase
        
        % Run simulator to obtain log lik for training points
        rss = Run_simulator_FitzNagumo(par, time, tspan, trueData, sc, extra_p);
        
        noODE_counter_InitExpl = noODE_counter_InitExpl + size(X,1);
        
        k = 500; % no of points we want to keep to fit the GP regression
        temp = sort(sum(rss,2), 'ascend');
        T_ss = temp(k);
        
        I_ss = sum(rss,2)<T_ss;
        x_regr = par(I_ss,:); y_regr = rss(I_ss,:);
                
        mean_y = mean(y_regr);
        std_y = std(y_regr);
        
        y_regr = (y_regr-mean_y)./std_y; % mean 0 and std 1 of of y
        
        for is=1:ns
            
            gp_regr(is) = GPmodel(x_regr, y_regr(:,is), [1 0.01 0.01 0.01 0.001]);
            
            [w,s] = gp_pak(gp_regr(is));
            disp(exp(w))
            
            %Make predictions using gp_regr
            [E, Var] = gp_pred(gp_regr(is), x_regr, y_regr(:,is), x_regr);
            figure(is); clf(is); plot(y_regr(:,is), E, '.');
            hold on; plot(y_regr(:,is),y_regr(:,is),'-r')
            xlabel('Train data'); ylabel('Predictions')
            
        end
        
        %% Run the exploratory phase of the GPHMC algorithm
        
        phase_ind = 1; % phase 1 in GPHMC algorithm
        
        % Set priors
        % for the ODE parameters
        % gamma prior:
        alp = [2,2,2];
        bet = [1,1,1];
        
        % for the noise variance (IG)
        a = 0.001; b = 0.001; % uninformative
        
        x_regr_refitted = x_regr;
        y_regr_refitted = y_regr;
        
        for is=1:ns
            
            gp_regr_refitted(is) = gp_regr(is);
            
            % Obtain the covariance matrix and find its inverse to pass on by reference
            % to the functions as to avoid the repeated matrix inversion
            [~,Cov] = gp_trcov(gp_regr_refitted(is), x_regr_refitted);
            Lcov = chol(Cov,'lower');
            invL = Lcov\eye(size(y_regr_refitted,1),size(y_regr_refitted,1)); % inverse of Lcov
            % Cov = Lcov'Lcov; Cov^(-1) = (Lcov'Lcov)^(-1) = (Lcov')^(-1)(Lcov^(-1)) = (Lcov^(-1))'(Lcov^(-1))
            % (Lcov')^(-1) = (Lcov^(-1))', inverse of transpose is transpose of inverse for a triangular matrix
            invLref(is) = largematrix; % create an object to pass the inverse of Lcov as an argument by reference
            invLref(is).array = invL;
        end
        
        do_nuts = 0;
        
        nSamples = 500;
        
        p = NaN(nSamples,nd); % theta parameter samples
        ss = NaN(nSamples,ns);
        
        sigma2 = sigma2_true;
        
        % Initialise
        p(1,:) = log(x_regr(1,:).*sc);% this is unbounded variable
       
        em_ind = 0; grad1_SimInd = 0; grad23_EmInd = [NaN NaN];
        [LogPosterior_sim, ~, ~, ~, ~, ss(1,:)] = ...
            HMCDerivPosterior_all_FitzNagumo(p(1,:), sigma2, trueData, time, tspan, ...
            alp, bet, nd, sc, extra_p, em_ind, phase_ind, grad1_SimInd, grad23_EmInd, ...
            gp_regr_refitted, x_regr_refitted, ...
            y_regr_refitted, mean_y, std_y, do_nuts, invLref);
        
        noODE_counter_InitExpl = noODE_counter_InitExpl + size(X,1);
        
        em_ind = 1; grad1_SimInd = NaN; grad23_EmInd = [0 0];
        [LogPosterior_em,GradLogPost_em] = ...
            HMCDerivPosterior_all_FitzNagumo(p(1,:), sigma2, trueData, time, tspan, ...
            alp, bet, nd, sc, extra_p, em_ind, phase_ind, grad1_SimInd, grad23_EmInd, ...
            gp_regr_refitted, x_regr_refitted, ...
            y_regr_refitted, mean_y, std_y, do_nuts, invLref);
        
        acc = 0; % acceptance rate
        
        M = eye(nd,nd);
        
        do_DA = 1; % do DA in the exploratory phase
        % (it doesn't matter what we use in the exploratory phase when we construct the emulator)
        
        % in exploratory phase, draw eps and L from uniform with the
        % following bounds:
        l_eps = 0.001; u_eps = 0.005;
        l_L = 20; u_L = 30; 
        epsilon = l_eps + (u_eps-l_eps)*rand; L = round(l_L + (u_L-l_L)*rand);
        
        j = 1;
        
        T_ss1 = quantile(y_regr_refitted(:,1).*std_y(1)+mean_y(1),0.5);
        T_ss2 = quantile(y_regr_refitted(:,2).*std_y(2)+mean_y(2),0.5);
        T_ss = T_ss1 + T_ss2;
        
        opt=optimset('TolFun',1e-6,'TolX',1e-6);
        
        rng('shuffle')
        
        % Enter HMC loop to draw nSamples
        for i=2:nSamples
            [p(i,:),LogPosterior_sim,LogPosterior_em,GradLogPost_em, ss(i,:), ...
                noODE_counter_iter, gp_regr_refitted, ...
                x_regr_refitted, y_regr_refitted, mean_y, std_y,invLref] = ...
                HMC_FitzNagumo(p(i-1,:), sigma2, epsilon, L, ...
                gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
                nd, phase_ind, trueData, time, tspan, alp, bet, sc, extra_p, ...
                LogPosterior_sim, LogPosterior_em, ...
                GradLogPost_em, ss(i-1,:), mean_y, std_y, do_nuts, M, ...
                invLref, do_DA);
            
            noODE_counter_InitExpl = noODE_counter_InitExpl + noODE_counter_iter;
            
            if all(p(i,:) ~= p(i-1,:)) % we've just accepted the new point
                
                %sum(ss(i,:))
                
                acc = acc + 1;
                
                % starting from beginning, gradually remove the old [size(y_regr,1)] training
                % points whose rss > T_ss, as we accept new train points & refit GP
                if acc <= size(y_regr,1) % delete or skip when we've accepted
                    y_regr_refitted = y_regr_refitted .* std_y + mean_y;
                    x_regr_refitted(j,:) = []; y_regr_refitted(j,:) = [];
                    mean_y = mean(y_regr_refitted); std_y = std(y_regr_refitted);
                    y_regr_refitted = (y_regr_refitted - mean_y)./std_y;

                else
                    j = j + 1; % skip deleting
                end
            end
            
            param = exp(p(i,:)); % parameters on original scale
            param_em = param./sc; % parameters used in emulation
            
            if x_regr_refitted(end,:)~=param_em % i.e. if we haven't already
                % added this point as a consequence of sqrt(Var)>=3
                
                x_regr_refitted(end+1,:) = param_em;
                y_regr_refitted = y_regr_refitted .* std_y + mean_y; % bring on original scale
                y_regr_refitted(end+1,:) = ss(i,:); % original scale
                
                mean_y = mean(y_regr_refitted);
                std_y = std(y_regr_refitted);
                y_regr_refitted = (y_regr_refitted - mean_y)./std_y;
                
                for is=1:ns
                    gp_regr_refitted(is) = gp_optim(gp_regr_refitted(is),...
                        x_regr_refitted,y_regr_refitted(:,is),'opt',opt);
                    
                    % Update cov matrix here to pass on by reference
                    [~,Cov] = gp_trcov(gp_regr_refitted(is), x_regr_refitted);
                    Lcov = chol(Cov,'lower');
                    invL = Lcov\eye(size(y_regr_refitted,1),size(y_regr_refitted,1)); % inverse of Lcov
                    % Cov = Lcov'Lcov; Cov^(-1) = (Lcov'Lcov)^(-1) = (Lcov')^(-1)(Lcov^(-1)) = (Lcov^(-1))'(Lcov^(-1))
                    % (Lcov')^(-1) = (Lcov^(-1))', inverse of transpose is transpose of inverse for a triangular matrix
                    %invLref = largematrix; % create an object to pass the inverse of Lcov as an argument by reference
                    invLref(is).array = invL;
                end
                
            end
            
        end
        
        if i>nSamples/2
            sigma2 = 1./gamrnd(a+0.5*n, 1./(b+0.5*ss(i,:)));
        end
        
        
        epsilon = l_eps + (u_eps-l_eps)*rand; L = round(l_L + (u_L-l_L)*rand);
        
    end
    
    y_regr_refitted = y_regr_refitted .* std_y + mean_y;
    k = 450; % no of points we want to keep to fit the GP regression
    temp = sort(sum(y_regr_refitted,2), 'ascend');
    T_ss = temp(k);
    I_ss = find(sum(y_regr_refitted,2) < T_ss);
    y_regr_refitted = y_regr_refitted(I_ss,:);
    x_regr_refitted = x_regr_refitted(I_ss,:);
    mean_y = mean(y_regr_refitted);
    std_y = std(y_regr_refitted);
    
    y_regr_refitted = (y_regr_refitted - mean_y)./std_y;
    
    % Refit GP with burnin phase removed
    % Use this GP in the sampling phase
    for is=1:ns
        gp_regr_refitted(is) = gp_optim(gp_regr_refitted(is),...
            x_regr_refitted,y_regr_refitted(:,is),'opt',opt);
        
        % Update the covariance matrix and its inverse
        [~,Cov] = gp_trcov(gp_regr_refitted(is), x_regr_refitted);
        Lcov = chol(Cov,'lower');
        invL = Lcov\eye(size(y_regr_refitted,1),size(y_regr_refitted,1)); % inverse of Lcov
        % Cov = Lcov'Lcov; Cov^(-1) = (Lcov'Lcov)^(-1) = (Lcov')^(-1)(Lcov^(-1)) = (Lcov^(-1))'(Lcov^(-1))
        % (Lcov')^(-1) = (Lcov^(-1))', inverse of transpose is transpose of inverse for a triangular matrix
        %invLref = largematrix; % create an object to pass the inverse of Lcov as an argument by reference
        invLref(is).array = invL;
    end
    
    fname = sprintf('PaperResults_GPHMC_Exploratory_FitzNagumo_dataset %d.mat', ids);
    matfile = fullfile(ResultsDestination,fname);
    save(matfile)
    
%% Run initial design for Bayesian Optimization (sampling phase)

if 1
    
    fname = sprintf('Results/PaperResults_GPHMC_Exploratory_FitzNagumo_dataset %d.mat', ids);
    load(fname)
    
    do_DA = 1; % do delayed acceptance
    
    hd = 2; % no of hyperparameters for HMC (epsilon, L)
    % Set lower and upper bounds for epsilon and L in HMC to be used in
    % Bayesian optimization
    l_HMC = [10^(-4), 1];
    u_HMC = [10^(-2), 500];
    sc_E = u_HMC; % scaling for (eps, L) to be used in GP
    
    M = eye(nd,nd);
    
    X = sobolset(hd, 'Skip',1.4e4,'Leap',0.45e15); % draw 21 points
    np = size(X, 1);
    
    % Use first 20 points from Sobol sequence to build initial GP model
    epsilon_init = l_HMC(1) + (u_HMC(1)-l_HMC(1)) * X(1:np,1);
    L_init = round(l_HMC(2) + (u_HMC(2)-l_HMC(2)) * X(1:np,2)); % L integer
    
    % Set number of HMC samples to generate for every (eps, L) pair
    nSamples = 11; % draw nSamples-1 for every (eps,L) starting from previous run sample
    % (that'll be the 1st out of nSamples)
    
    % Sampling phase in Rasmussen's paper
    phase_ind = 2;
    
    % Pre-allocate memory for chains
    p_sample_init = NaN((nSamples-1)*(np-1)+1, nd); % parameter samples from initial stage
    nESJD_init = NaN(np,1); % normalised ESJD from initial stage (only the successful runs (nESJD>0))
    
    ss_sample_init = NaN((nSamples-1)*(np-1)+1, ns); % sum-of-square samples from the sampling phase
    s2_sample_init = NaN((nSamples-1)*(np-1)+1, ns); % sigma2 samples from the sampling phase
    
    % Initialise
    i = 100;
    p_sample_init(1,:) = log(x_regr_refitted(i,:).*sc);% this is unbounded variable
    s2_sample_init(1,:) = (y_regr_refitted(i,:).*std_y+mean_y)./n;
    
    noODE_counter_preproc = 0; % count no of ODE evaluations in the pre-processing phase
    
    
    em_ind = 0; grad1_SimInd = 0; grad23_EmInd = [NaN NaN];
    [LogPosterior_sim, ~, ~, ~, ~, ss_sample_init(1,:)] = ...
        HMCDerivPosterior_all_FitzNagumo(p_sample_init(1,:), ...
        s2_sample_init(1,:), trueData, time, tspan, alp, bet, nd, sc, ...
        extra_p, em_ind, phase_ind, grad1_SimInd, grad23_EmInd, ...
        gp_regr_refitted,x_regr_refitted, ...
        y_regr_refitted, mean_y, std_y, do_nuts, invLref);
    
    noODE_counter_preproc = noODE_counter_preproc + 1;
    
    em_ind = 1; grad1_SimInd = NaN; grad23_EmInd = [0 0];
    [LogPosterior_em,GradLogPost_em] = ...
        HMCDerivPosterior_all_FitzNagumo(p_sample_init(1,:), ...
        s2_sample_init(1,:), trueData, time, tspan, ...
        alp, bet, nd, sc, extra_p, em_ind, phase_ind, grad1_SimInd, ...
        grad23_EmInd, gp_regr_refitted, ...
        x_regr_refitted, y_regr_refitted, mean_y, std_y, do_nuts, invLref);
    
    acc = 0; % acceptance rate
    next = 1;
    
    initime = cputime();
    
    tic()
    
    rng('shuffle')
    
    for j = 1:np-1 % iterate through different (eps, L) pairs
        % to obtain nSamples for each pair
        for i=2:nSamples
            
            next = next + 1;
            [p_sample_init(next,:),LogPosterior_sim,LogPosterior_em,...
                GradLogPost_em, ss_sample_init(next,:), noODE_counter_iter] = ...
                HMC_FitzNagumo(p_sample_init(next-1,:), ...
                s2_sample_init(next-1,:), epsilon_init(j), L_init(j), ...
                gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
                nd, phase_ind, trueData, time, tspan, alp, bet, sc, ...
                extra_p, LogPosterior_sim, LogPosterior_em, ...
                GradLogPost_em, ss_sample_init(next-1,:), ...
                mean_y, std_y, do_nuts, M, invLref, do_DA);
            
            noODE_counter_preproc = noODE_counter_preproc + noODE_counter_iter;
            
            if all(p_sample_init(next,:) ~= p_sample_init(next-1,:)) % we've just accepted the new point
                %disp('accept')
                acc = acc + 1;
            else
                %disp('reject')
            end
            
            s2_sample_init(next,:) = 1./gamrnd(a+0.5*n, 1./(b+0.5*ss_sample_init(next,:)));
            
        end
        
        xj = p_sample_init(next-nSamples+1:next,:);
        nESJD_init(j) = ESJDfct(xj)/sqrt(L_init(j));
        %nESJD_init(j)
        
    end
    
    ElapsedTime_BO_HMC_exploratoryTrain = toc();
    
    CPUtime_BO_HMC_exploratoryTrain = cputime()-initime;
    
    
    % Construct data set: ((eps, L), nESJD_init) on which we run initial GP model
    % nESJD_init must have np length
    x_E = [epsilon_init(1:np-1), L_init(1:np-1)]./sc_E; % (np,2) size
    y_E = nESJD_init(1:np-1);
    
    mean_y_E = mean(y_E);
    std_y_E = std(y_E);
    
    y_E = (y_E-mean_y_E)./std_y_E; % mean 0 and std 1 of of y_E
    
    gp_E = GPmodel_nESJD(x_E, y_E, l_HMC./sc_E, u_HMC./sc_E);
    
    [w,~] = gp_pak(gp_E);
    disp(exp(w))
    
    %Make predictions using gp_E
    [E, Var] = gp_pred(gp_E, x_E, y_E, x_E);
    figure(1); clf(1); plot(y_E, E, '.', 'markersize', 20);
    hold on; plot(y_E,y_E,'-r')
    xlabel('Train data'); ylabel('Predictions')
    
    
    %% Main BO where we find best epsilon and L
    
    delta = 0.1;
    
    % Set maximum no of BO iterations
    % no of HMC samples to generate for every (eps, L) pair is 1 + (nSamples-1)*maxiter
    maxiter = 50;
    
    epsilon_adapt = NaN(maxiter,1); % stores the optimum step size from every BO iteration
    L_adapt = NaN(maxiter,1); % stores the optimum no of leapfrog steps from every BO iteration
    
    epsilon_adapt(1) = l_HMC(1) + (u_HMC(1)-l_HMC(1)) * X(np,1);
    L_adapt(1) = round(l_HMC(2) + (u_HMC(2)-l_HMC(2)) * X(np,2)); % L integer
    
    phase_ind = 2;
    
    p_sample_initCont = NaN(1 + (nSamples-1)*maxiter,nd); % param samples
    ss_sample_initCont = NaN(1 + (nSamples-1)*maxiter,ns); % sum-of-square samples
    s2_sample_initCont = NaN(1 + (nSamples-1)*maxiter,ns); % sigma2 samples from the sampling phase
    
    nESJD = NaN(maxiter,1);
    
    % Initialise position vector with last param values from the initial design
    p_sample_initCont(1,:) = p_sample_init(end,:);
    ss_sample_initCont(1,:) = ss_sample_init(end,:);
    s2_sample_initCont(1,:) = s2_sample_init(end,:);
    
    % Also refine LogPost and Grads for the new s2
    em_ind = 0; grad1_SimInd = 0; grad23_EmInd = [NaN NaN];
    [LogPosterior_sim, ~, ~, ~, ~, ss_sample_initCont(1,:)] = ...
        HMCDerivPosterior_all_FitzNagumo(p_sample_initCont(1,:), ...
        s2_sample_initCont(1,:), trueData, ...
        time, tspan, alp, bet, nd, sc, extra_p, em_ind, phase_ind, ...
        grad1_SimInd, grad23_EmInd, gp_regr_refitted, x_regr_refitted, ...
        y_regr_refitted, mean_y, std_y, do_nuts, invLref);
    
    noODE_counter_preproc = noODE_counter_preproc + 1;
    
    em_ind = 1; grad1_SimInd = NaN; grad23_EmInd = [0 0];
    [LogPosterior_em,GradLogPost_em] = ...
        HMCDerivPosterior_all_FitzNagumo(p_sample_initCont(1,:), ...
        s2_sample_initCont(1,:), trueData, time, tspan, ...
        alp, bet, nd, sc, extra_p, em_ind, phase_ind, grad1_SimInd, ...
        grad23_EmInd, gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
        mean_y, std_y, do_nuts, invLref);
    
    nstarts = 20; % for the optimisation of the acquisition function
    
    delete(gcp('nocreate'))
    parpool('local', nstarts)
    
    nESJD_augm = NaN(maxiter+np-1,1);
    x_E_augm = NaN(maxiter+np-1,2);
    
    nESJD_augm(1:np-1) = nESJD_init(1:np-1); % this is unscaled
    x_E = [epsilon_init(1:np-1), L_init(1:np-1)]./sc_E; % (np,2) size
    x_E_augm(1:np-1,:) = x_E; % already scaled
    
    next = 1; % keeps track of the iteration no in the Markov chain for the ODE param
    ind = np-1; % keeps track of the iteration no in the list of training points for nESJD
    acc = 0;
    
    initime = cputime();
    
    tic()
    
    rng('shuffle')
    
    for j = 1:maxiter
        % Run HMC nSample times for [epsilon_adapt(j), L_adapt(j)]
        for i = 2:nSamples
            % Call HMC_fast to get p_sample_initCont
            next = next + 1;
            [p_sample_initCont(next,:),LogPosterior_sim,LogPosterior_em,...
                GradLogPost_em,ss_sample_initCont(next,:), noODE_counter_iter] = ...
                HMC_FitzNagumo(p_sample_initCont(next-1,:), ...
                s2_sample_initCont(next-1,:), epsilon_adapt(j), L_adapt(j), ...
                gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
                nd, phase_ind, trueData, time, tspan, alp, bet, sc, extra_p, ...
                LogPosterior_sim, LogPosterior_em, GradLogPost_em, ...
                ss_sample_initCont(next-1,:), mean_y, std_y, do_nuts, ...
                M, invLref, do_DA);
            
            noODE_counter_preproc = noODE_counter_preproc + noODE_counter_iter;
            
            if all(p_sample_initCont(next,:) ~= p_sample_initCont(next-1,:)) % i.e. we've just accepted the new point
                %disp('accept')
                acc = acc + 1;
            else
                %disp('reject')
            end
            
            s2_sample_initCont(next,:) = 1./gamrnd(a+0.5*n, 1./(b+0.5*ss_sample_initCont(next,:)));
            
        end % nSamples
        
        %If we have gathered np data points in the sampling phase for the GP,
        %discard the points from the burnin phase (np points) not to affect the inference
        if (j == np)
            nESJD_augm(1:np) = []; x_E_augm(1:np,:) = [];
            ind = ind - j;
        end
        
        % Obtain the objective function
        xj = p_sample_initCont(next-nSamples+1:next,:);
        nESJD(j) = ESJDfct(xj)/sqrt(L_adapt(j));
        
        % Augment data set with ([eps(j), L(j)], nESJD(j))
        ind = ind + 1;
        nESJD_augm(ind) = nESJD(j);
        x_E_augm(ind,:) = [epsilon_adapt(j), L_adapt(j)]./sc_E;
        
        % Re-train GP
        mean_y_E = mean(nESJD_augm(1:ind));
        std_y_E = std(nESJD_augm(1:ind));
        x_E = x_E_augm(1:ind,:); y_E = (nESJD_augm(1:ind) - mean_y_E)./std_y_E;
        
        gp_E = gp_optim(gp_E,x_E,y_E); % refine cov hyperparameters
        
        % Conduct Bayesian Optimisation
        betaj = 2*log((pi^2*(j+1)^(hd/2+2))/(3*delta));
        pj = 1; % to recover the original upper confidence bound function
        s = 1; % we don't need the rescale parameter as we are already scaling the data to zero mean, variance 1
        fh_ucb = @(x_new) UpperConfBound(x_new, gp_E, x_E, y_E, ...
            mean_y_E, std_y_E, s, pj, betaj);
        % Set the options for optimizer of the acquisition function
        optimf = @fmincon;
        
        optdefault=struct('LargeScale','off','Display', 'off', ...
            'Algorithm','active-set','TolFun',1e-8,'TolX',1e-8, ...
            'GradObj','on','SpecifyObjectiveGradient',true);
        
        options = optimset(optdefault);
        
        x0_E = NaN(nstarts, hd);
        x_E_optims = NaN(nstarts, hd); f_E_optims = NaN(nstarts, 1);
        
        parfor s1 = 1:nstarts
            % initial epsilon and L for the optimization
            x0_E(s1,:) = l_HMC./sc_E+(u_HMC-l_HMC)./sc_E * rand;
            
            [x_E_optims(s1,:), f_E_optims(s1)] = ...
                optimf(fh_ucb, x0_E(s1,:), [], [], [], [], ...
                l_HMC./sc_E, u_HMC./sc_E, [], options);
        end
        
        I_min = find(f_E_optims==min(f_E_optims));
        x_E_optim = x_E_optims(I_min(1),:);
        f_E_optim = f_E_optims(I_min(1));
        
        % Store new optimum
        epsilon_adapt(j+1) = x_E_optim(1)*sc_E(1);
        L_adapt(j+1) = round(x_E_optim(2)*sc_E(2)); % L integer
        
    end %maxiter
    
    % Now find the 'best' epsilon and L (i.e. that have generated the highest nESJD)
    bestEps = x_E_augm(nESJD_augm==max(nESJD_augm),1)*sc_E(1);
    bestL = round(x_E_augm(nESJD_augm==max(nESJD_augm),2)*sc_E(2));
    
    ElapsedTime_BO_HMC_exploratoryTrain = toc() + ElapsedTime_BO_HMC_exploratoryTrain;
    
    CPUtime_BO_HMC_exploratoryTrain = cputime()-initime + CPUtime_BO_HMC_exploratoryTrain;
    
    
    fname = sprintf('BO_HMC_FindBestEpsL_FitzNagumo_dataset %d.mat', ids);
    matfile = fullfile(ResultsDestination,fname);
    save(matfile)
    
end

%%
% Now run HMC with the 'best' epsilon and L identified (3 times) for
% every data set
% Eps and L used are the same for DA and noDA and across different runs for
% DA and noDA (this removes the confounding effect of the BO scheme and
% focuses on the effect of DA vs noDA)

load(sprintf('Results/BO_HMC_FindBestEpsL_FitzNagumo_dataset %d.mat', ids));

for it = 1:ntimeit
    
    do_DA = 1; % do delayed acceptance
    
    nSamples = 2000; % no of sampling phase samples
    nburnin = 500; % no of burnin phase samples
    L = bestL; % no of steps in leapfrog scheme
    epsilon = bestEps; % step size in leapfrog scheme
    phase_ind = 2; % phase index in Rasmussen's paper
    
    M = eye(nd); % mass matrix for momentum
    
    nrun = 10; % run 10 chains in parallel
    acc = zeros(nrun,1); % acceptance rate for every chain
    
    p_sample = cell(nrun,1); % parameter samples from the sampling phase
    s2_sample = cell(nrun,1); % sigma2 samples from the sampling phase
    ss_sample = cell(nrun,1); % sigma2 samples from the sampling phase
    
    noODE_counter_proc = zeros(nrun,1); % count no of ODE evaluations in the processing (sampling) phase
    
    delete(gcp('nocreate'))
    parpool('local', nrun)
    
    % Store cpu times for every run and average the at the end
    initime = NaN(nrun,1);
    fintime = NaN(nrun,1);
    
    p1 = Par(nd);
    
    % Run 10 chains in parallel from different initialisations and different
    % random seed generators
    
    parfor j=1:nrun
        
        noODE_counter_run = 0;
        
        % Initialise
        p0 = x_regr_refitted(end-j,:) .* sc; % original scale
        p_sample{j}(1,:) = log(p0); % unbounded
        
        ss_sample{j}(1,:) = Run_simulator_FitzNagumo(p0./sc, time, ...
            tspan, trueData, sc, extra_p);
        
        s2_sample{j}(1,:) = ss_sample{j}(1,:)/n;
        
        % Get initial log likelihood, log posterior and gradient of log posterior
        % w.r.t. every theta_i
        em_ind = 0; grad1_SimInd = 0; grad23_EmInd = [NaN NaN];
        [LogPosterior_sim, ~, ~, ~, ~, ss_sample{j}(1,:)] = ...
            HMCDerivPosterior_all_FitzNagumo(p_sample{j}(1,:), ...
            s2_sample{j}(1,:), trueData, ...
            time, tspan, alp, bet, nd, sc, extra_p, em_ind, ...
            phase_ind, grad1_SimInd, grad23_EmInd, gp_regr_refitted, ...
            x_regr_refitted, y_regr_refitted, mean_y, std_y, do_nuts, invLref);
        
        em_ind = 1;
        grad1_SimInd = NaN;
        grad23_EmInd = [0 0];
        [LogPosterior_em,GradLogPost_em] = ...
            HMCDerivPosterior_all_FitzNagumo(p_sample{j}(1,:), ...
            s2_sample{j}(1,:), trueData, ...
            time, tspan, alp, bet, nd, sc, extra_p, em_ind, ...
            phase_ind, grad1_SimInd, grad23_EmInd, gp_regr_refitted, ...
            x_regr_refitted, y_regr_refitted, mean_y, std_y, do_nuts, invLref);
        
        % Enter HMC loop to draw nSamples
        for i=2:nSamples+nburnin
            
            if i == nburnin + 1 % start measuring after the burnin
                initime(j) = cputime;
                Par.tic;
            end
            
            [p_sample{j}(i,:),LogPosterior_sim,LogPosterior_em,...
                GradLogPost_em, ss_sample{j}(i,:), no_counter_iter] = ...
                HMC_FitzNagumo(p_sample{j}(i-1,:), s2_sample{j}(i-1,:), ...
                epsilon, ceil(rand*L), gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
                nd, phase_ind, trueData, time, tspan, alp, bet, sc, extra_p, ...
                LogPosterior_sim, LogPosterior_em, ...
                GradLogPost_em, ss_sample{j}(i-1,:), mean_y, std_y, ...
                do_nuts, M, invLref, do_DA);
            
            if i > nburnin % start counting in the sampling phase
                noODE_counter_run = noODE_counter_run + no_counter_iter;
            end
            
            %ss_sample{j}(i);
            
            if all(p_sample{j}(i,:) ~= p_sample{j}(i-1,:)) % we've just accepted the new point
                acc(j) = acc(j) + 1;
                %fprintf('accept for run %d \n',j)
            end
            
            
            if i<nburnin % sample sigma2 in sampling phase
                s2_sample{j}(i,:) = s2_sample{j}(i-1,:);
            else
                %disp('sampling phase')
                s2_sample{j}(i,:) = 1./gamrnd(a+0.5*n, 1./(b+0.5*ss_sample{j}(i,:)));
            end
            
            
        end
        
        noODE_counter_proc(j) = noODE_counter_proc(j) + noODE_counter_run;
        
        p1(j) = Par.toc;
        
        fintime(j) = cputime;
    end
    
    CPUtime_BO_DAGPHMC_sampling = fintime-initime;
    
    ElapsedTime_BO_DAGPHMC_sampling = NaN(nd,1);
    
    for j=1:nrun
        ElapsedTime_BO_DAGPHMC_sampling(j) = p1(1,j).ItStop - p1(1,j).ItStart;
    end
    
    fname = sprintf('FitzNagumo_dataset %d_BO_DAGPHMC_sampling %d.mat', ids, it);
    matfile = fullfile(ResultsDestination,fname);
    save(matfile)
    
end % ntimeit

end % nds

exit;