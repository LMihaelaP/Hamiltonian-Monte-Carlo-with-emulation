function [current_p,LogPosterior_sim,LogPosterior_em,GradLogPost_em,...
    GradGradLogPost_em, GradGradGradLogPost_em, ObjFct_sim, noODE_counter, posdef] = ...
    RMHMC_FitzNagumo_forHybrid(current_p, sigma2, StepSize, L, ...
    gp_regr, x_regr, y_regr, nd, phase_ind, trueData, time, tspan, ...
    alp, bet, sc, extra_p, ...
    LogPosterior_sim_begin, LogPosterior_em_begin, GradLogPost_em_begin, ...
    GradGradLogPost_em_begin, GradGradGradLogPost_em_begin, ObjFct_sim_begin, ...
    mean_y, std_y, do_nuts, invLref, do_DA, NumOfNewtonSteps)

% Runs an iteration of the Riemann Manifold HMC

noODE_counter = 0; % count the no of ODE evaluations

p = current_p';

% Obtain LogPost, GradLogPost, GradGradLogPost and GradGradGradLogPost
% at the beginning of the trajectory
% It may not be the same one as that saved at the previous iteration for
% the accepted point since the noise variance, if sampled in a Gibbs step
% will lead to a different LogLik

em_ind = 1; % use emulator
grad1_SimInd = NaN; grad23_EmInd = [1 1];
[LogPosterior_em_begin,GradLogPost_em_begin,GradGradLogPost_em_begin,...
    GradGradGradLogPost_em_begin, ~, ~, FirstSecondGradProd_em_begin] = ...
    HMCDerivPosterior_all_FitzNagumo(p', ...
    sigma2, trueData, time, tspan, alp, bet, nd, sc, extra_p, ...
    em_ind, phase_ind, grad1_SimInd, grad23_EmInd, ...
    gp_regr, x_regr, y_regr, mean_y, std_y, do_nuts, invLref);

n = size(trueData,1);

LogPosterior_sim_begin = sum ( -n/2.*log(sigma2)-n/2*log(2*pi)*size(sigma2,1) - ...
    ObjFct_sim_begin./(2.*sigma2) ) + Prior_Log_GradLog(p', alp, bet, do_nuts);

% Get G
lambda = 0.0;

% the outer product will produce a semi-positive or positive definite matrix:
% GradLogPost_em_begin*GradLogPost_em_begin'
G_current = (1-lambda) .* (-GradGradLogPost_em_begin) + lambda .* (GradLogPost_em_begin*GradLogPost_em_begin');

G = G_current;

G = G + (1e-06)*eye(nd,nd);

[~,posdef] = chol(G);

if cond(G)>1e+15 % high condition number
    posdef = 1; % posdef from chol can still be 0,
    % but I get warnings that matrix is close to singular or
    % badly scaled when inverting it
end

if posdef ~= 0
    LogPosterior_em = LogPosterior_em_begin;
    GradLogPost_em = GradLogPost_em_begin;
    GradGradLogPost_em = GradGradLogPost_em_begin;
    GradGradGradLogPost_em = GradGradGradLogPost_em_begin;
    LogPosterior_sim = LogPosterior_sim_begin;
    ObjFct_sim = ObjFct_sim_begin;
    current_p = current_p;
    
    return
    
else
    
    OriginalG     = G;
    
    OriginalCholG = chol(G);
    
    % Get the partial derivatives dG/dphi
    GDeriv = NaN(repmat(nd,1,3));
    for d = 1:nd
        GDeriv(:,:,d) = (1-lambda) .* (-GradGradGradLogPost_em_begin{d}) + lambda .* FirstSecondGradProd_em_begin{d};
    end
    % Calculate the partial derivatives dG/dq
    TraceInvGdG = NaN(1,nd);
    InvGdG = cell(nd,1);
    
    for d = 1:nd
        InvGdG{d} = G\GDeriv(:,:,d);
        TraceInvGdG(d) = trace(InvGdG{d});
        % OR they're equivalent
        % InvG = inv(G); TraceInvGdG(d) = sum(sum(InvG.*GDeriv(:,:,d)'));
    end
    
    ProposedMomentum = (randn(1,nd)*OriginalCholG)';
    OriginalMomentum = ProposedMomentum;
    
    CurrentLJL = LogPosterior_em_begin;
    
    % Calculate current H value
    CurrentLogDet = 0.5*( nd*log(2) + nd*log(pi) + 2*sum(log(diag(OriginalCholG))) );
    
    %CurrentH  = -CurrentLJL + CurrentLogDet + (OriginalMomentum'*OriginalInvG*OriginalMomentum)/2;
    CurrentH  = -CurrentLJL + CurrentLogDet + (OriginalMomentum'/OriginalG*OriginalMomentum)/2;
    
    if (randn > 0.5) TimeStep = 1; else TimeStep = -1; end
    
    %RandomSteps = ceil(rand*L); % L = no of leapfrog steps
    
    % Perform leapfrog steps
    for StepNum = 1:L %RandomSteps
        
        %%%%%%%%%%%%%%%%%%%
        % Update momentum %
        %%%%%%%%%%%%%%%%%%%
        em_ind = 1; grad1_SimInd = NaN; grad23_EmInd = [0 0];
        [~, GradLogPost_trj] = ...
            HMCDerivPosterior_all_FitzNagumo(p', sigma2, trueData, time, tspan, ...
            alp, bet, nd, sc, extra_p, em_ind, phase_ind, grad1_SimInd, grad23_EmInd, ...
            gp_regr, x_regr, y_regr, mean_y, std_y, do_nuts, invLref);
        
        dLdTheta  = GradLogPost_trj;
        TraceTerm = 0.5*TraceInvGdG';
        
        % Multiple fixed point iteration
        PM = ProposedMomentum;
        MomentumHist = NaN(NumOfNewtonSteps,nd);
        
        for FixedIter = 1:NumOfNewtonSteps
            MomentumHist(FixedIter,:) = PM;
            
            %         InvGMomentum = InvG*PM;
            InvGMomentum = G\PM;
            
            LastTerm = NaN(nd,1);
            for d = 1:nd
                LastTerm(d)  = 0.5*(PM'*InvGdG{d}*InvGMomentum);
            end
            
            PM = ProposedMomentum + TimeStep*(StepSize/2)*(dLdTheta - TraceTerm + LastTerm);
        end
        ProposedMomentum = PM;
        
        
        %%%%%%%%%%%%%%%%%%%%%%%
        % Update p parameters (position) %
        %%%%%%%%%%%%%%%%%%%%%%%
        
        %%% Multiple Fixed Point Iteration %%%
        OriginalInvGMomentum  = G\ProposedMomentum;
        
        Pu = p;
        pHist = NaN(NumOfNewtonSteps,nd);
        
        for FixedIter = 1:NumOfNewtonSteps
            pHist(FixedIter,:) = Pu;
            
            em_ind = 1; grad1_SimInd = NaN; grad23_EmInd = [1 0];
            [~, GradLogPost_trj, GradGradLogPost_trj] = ...
                HMCDerivPosterior_all_FitzNagumo(Pu', sigma2, trueData, time, tspan, ...
                alp, bet, nd, sc, extra_p, em_ind, phase_ind, grad1_SimInd, grad23_EmInd, ...
                gp_regr, x_regr, y_regr, mean_y, std_y, do_nuts, invLref);
            
            lambda = 0;
            
            G = (1-lambda) .* (-GradGradLogPost_trj) + lambda .* (GradLogPost_trj * GradLogPost_trj');
            
            G = G + (1e-06)*eye(nd,nd);
            
            [~,posdef] = chol(G);
            
            if cond(G)>1e+15
                posdef = 1; % posdef from chol can still be 0,
                % but I get warnings that matrix is close to singular or
                % badly scaled when inverting it
            end
            
            if posdef ~= 0
                
                break
                
            else
                
                InvGMomentum = G\ProposedMomentum;
                
                Pu = p + (TimeStep*(StepSize/2))*OriginalInvGMomentum + (TimeStep*(StepSize/2))*InvGMomentum;
                
            end % posdef
            
        end % FixedIter
        
        p = Pu;
        
        if any(abs(p)>10) % unrealistic values caused by unreliable metric tensor
            posdef = 1;
            break
        end
        
        % Calculate G based on new parameters
        em_ind = 1; grad1_SimInd = NaN; grad23_EmInd = [1 1];
        [LogPosterior_em_end, GradLogPost_em_end, GradGradLogPost_em_end, ...
            GradGradGradLogPost_em_end, ~, ~, FirstSecondGradProd_em_end] = ...
            HMCDerivPosterior_all_FitzNagumo(p', sigma2, trueData, time, tspan, ...
            alp, bet, nd, sc, extra_p, em_ind, phase_ind, grad1_SimInd, grad23_EmInd, ...
            gp_regr, x_regr, y_regr, mean_y, std_y, do_nuts, invLref);
        
        lambda = 0;
        
        G = (1-lambda) .* (-GradGradLogPost_em_end) + lambda .* (GradLogPost_em_end * GradLogPost_em_end');
        
        G = G + (1e-06)*eye(nd,nd);
        
        [~,posdef] = chol(G);
        
        if cond(G)>1e+15
            posdef = 1; % posdef from chol can still be 0,
            % but I get warnings that matrix is close to singular or badly scaled
        end
        
        if posdef ~= 0
            
            break
            
        else
            
            % Get the partial derivatives dG/dphi
            GDeriv = NaN(repmat(nd,1,3));
            for d = 1:nd
                GDeriv(:,:,d) = (1-lambda) .* (-GradGradGradLogPost_em_end{d}) + lambda .* FirstSecondGradProd_em_end{d};
            end
            % Calculate the partial derivatives dG/dq
            TraceInvGdG = NaN(1,nd);
            InvGdG = cell(nd,1);
            
            for d = 1:nd
                InvGdG{d} = G\GDeriv(:,:,d);
                TraceInvGdG(d) = trace(InvGdG{d});
                % OR they're equivalent
                % InvG = inv(G); TraceInvGdG(d) = sum(sum(InvG.*GDeriv(:,:,d)'));
            end
            
            %%%%%%%%%%%%%%%%%%%
            % Update momentum %
            %%%%%%%%%%%%%%%%%%%
            % Calculate last term in dH/dTheta
            %     InvGMomentum = (InvG*ProposedMomentum);
            InvGMomentum = (G\ProposedMomentum);
            
            LastTerm = NaN(nd,1);
            for d = 1:nd
                LastTerm(d)  = 0.5*(PM'*InvGdG{d}*InvGMomentum);
            end
            
            dHdTheta = GradLogPost_em_end - 0.5*TraceInvGdG' + LastTerm;
            
            ProposedMomentum = ProposedMomentum + TimeStep*(StepSize/2)*dHdTheta;
            
        end % posdef
        
    end % StepNum
    
    if posdef == 0 % i.e. no 'break'
        
        % Calculate proposed H value
        ProposedLJL = LogPosterior_em_end;
        
        if ProposedLJL~=-10^10 % only calculate MH ratio for non-zero likelihood
            
            try
                
                ProposedLogDet = 0.5*( nd*log(2) + nd*log(pi) + 2*sum(log(diag(chol(G)))) );
                
                % ProposedH = -ProposedLJL + ProposedLogDet + (ProposedMomentum'*InvG*ProposedMomentum)/2;
                ProposedH = -ProposedLJL + ProposedLogDet + (ProposedMomentum'/G*ProposedMomentum)/2;
                
                % Accept according to ratio
                Ratio = -ProposedH + CurrentH;
                
            catch
                
                ProposedLJL = -10^10;
                
            end
            
        end
        
        % Accept or reject the state at end of trajectory
        % (in a Metropolis step, i.e. random walk => symmetryc proposal distr),
        
        % current-proposed and not proposed-current as it would normally because
        % because proposed is actually -logpost
        
        if do_DA == 0 % no delayed acceptance
            
            if ProposedLJL == -10^10 % reject
                %disp('reject because of zero likelihood')
                LogPosterior_em = LogPosterior_em_begin;
                GradLogPost_em = GradLogPost_em_begin;
                GradGradLogPost_em = GradGradLogPost_em_begin;
                GradGradGradLogPost_em = GradGradGradLogPost_em_begin;
                LogPosterior_sim = LogPosterior_sim_begin;
                ObjFct_sim = ObjFct_sim_begin;
                current_p = current_p;
                %current_p
                
            else
                
                CurrentH_sim = -LogPosterior_sim_begin + CurrentLogDet + ...
                    (OriginalMomentum'/OriginalG*OriginalMomentum)/2;
                
                em_ind = 0; grad1_SimInd = 0; grad23_EmInd = [NaN NaN];
                [LogPosterior_sim_end, ~, ~, ~, ~, ObjFct_sim_end] = ...
                    HMCDerivPosterior_all_FitzNagumo(p', sigma2, trueData, time, tspan, ...
                    alp, bet, nd, sc, extra_p, em_ind, phase_ind, grad1_SimInd, grad23_EmInd, ...
                    gp_regr, x_regr, y_regr, mean_y, std_y, do_nuts, invLref);
                
                noODE_counter = noODE_counter + 1;
                
                ProposedH_sim = -LogPosterior_sim_end + ProposedLogDet + ...
                    (ProposedMomentum'/G*ProposedMomentum)/2;
                
                % Accept according to ratio
                Ratio_sim = -ProposedH_sim + CurrentH_sim;
                
                if Ratio_sim > 0 || (Ratio_sim > log(rand))
                    %disp('accept')
                    LogPosterior_em = LogPosterior_em_end;
                    GradLogPost_em = GradLogPost_em_end;
                    GradGradLogPost_em = GradGradLogPost_em_end;
                    GradGradGradLogPost_em = GradGradGradLogPost_em_end;
                    LogPosterior_sim = LogPosterior_sim_end;
                    ObjFct_sim = ObjFct_sim_end;
                    current_p = p;
                else
                    %disp('reject')
                    LogPosterior_em = LogPosterior_em_begin;
                    GradLogPost_em = GradLogPost_em_begin;
                    GradGradLogPost_em = GradGradLogPost_em_begin;
                    GradGradGradLogPost_em = GradGradGradLogPost_em_begin;
                    LogPosterior_sim = LogPosterior_sim_begin;
                    ObjFct_sim = ObjFct_sim_begin;
                    current_p = current_p;
                end
                
            end
            
        else % do_DA = 1
            
            if ProposedLJL == -10^10 % reject
                %disp('reject in stage 1 because of zero likelihood')
                LogPosterior_em = LogPosterior_em_begin;
                GradLogPost_em = GradLogPost_em_begin;
                GradGradLogPost_em = GradGradLogPost_em_begin;
                GradGradGradLogPost_em = GradGradGradLogPost_em_begin;
                LogPosterior_sim = LogPosterior_sim_begin;
                ObjFct_sim = ObjFct_sim_begin;
                current_p = current_p;
                %current_p
                
            else
                
                if Ratio > 0 || (Ratio > log(rand)) % accept in stage 1
                    %disp('accept in stage 1')
                    
                    % next calculate acc rate in stage 2 using the simulator in an MH step
                    em_ind = 0; grad1_SimInd = 0; grad23_EmInd = [NaN NaN];
                    [LogPosterior_sim_end, ~, ~, ~, ~, ObjFct_sim_end] = ...
                        HMCDerivPosterior_all_FitzNagumo(p', sigma2, trueData, time, tspan, ...
                        alp, bet, nd, sc, extra_p, em_ind, phase_ind, grad1_SimInd, grad23_EmInd, ...
                        gp_regr, x_regr, y_regr, mean_y, std_y, do_nuts, invLref);
                    
                    noODE_counter = noODE_counter + 1;
                    
                    %[LogPosterior_sim_begin,LogPosterior_em_begin]
                    %[LogPosterior_sim_end,LogPosterior_em_end]
                    
                    r2 = LogPosterior_sim_end - LogPosterior_sim_begin + ...
                        LogPosterior_em_begin - LogPosterior_em_end;
                    
                    if r2 > 0 || (r2 > log(rand)) % accept at 2nd stage
                        %disp('accept in stage 2')
                        LogPosterior_em = LogPosterior_em_end;
                        GradLogPost_em = GradLogPost_em_end;
                        GradGradLogPost_em = GradGradLogPost_em_end;
                        GradGradGradLogPost_em = GradGradGradLogPost_em_end;
                        LogPosterior_sim = LogPosterior_sim_end;
                        ObjFct_sim = ObjFct_sim_end;
                        current_p = p;
                        
                    else % reject at 2nd stage
                        %disp('reject in stage 2')
                        LogPosterior_em = LogPosterior_em_begin;
                        GradLogPost_em = GradLogPost_em_begin;
                        GradGradLogPost_em = GradGradLogPost_em_begin;
                        GradGradGradLogPost_em = GradGradGradLogPost_em_begin;
                        LogPosterior_sim = LogPosterior_sim_begin;
                        ObjFct_sim = ObjFct_sim_begin;
                        current_p = current_p;
                        
                    end
                    
                else % reject in stage 1
                    %disp('reject in stage 1')
                    LogPosterior_em = LogPosterior_em_begin;
                    GradLogPost_em = GradLogPost_em_begin;
                    GradGradLogPost_em = GradGradLogPost_em_begin;
                    GradGradGradLogPost_em = GradGradGradLogPost_em_begin;
                    LogPosterior_sim = LogPosterior_sim_begin;
                    ObjFct_sim = ObjFct_sim_begin;
                    current_p = current_p;
                    %current_p
                    
                end % Ratio
                
            end % ProposedLJL
            
        end % do_DA
        
    else % posdef~=0, i.e. break
        
        LogPosterior_em = LogPosterior_em_begin;
        GradLogPost_em = GradLogPost_em_begin;
        GradGradLogPost_em = GradGradLogPost_em_begin;
        GradGradGradLogPost_em = GradGradGradLogPost_em_begin;
        LogPosterior_sim = LogPosterior_sim_begin;
        ObjFct_sim = ObjFct_sim_begin;
        current_p = current_p;
        
    end
    
end % posdef

end