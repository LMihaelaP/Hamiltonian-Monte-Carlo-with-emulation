function dsoldt = SolveODEs_FitzHughNagumo(t, y, param)
% Solves a system of nonlinear ODEs for the FitzHugh-Nagumo model

% Parameters
gamma = param(1); alpha = param(2); beta = param(3);

% Species
V = y(1); R = y(2);

dsoldt = [ gamma * ( V - V^3/3 + R ); - (1/gamma) * ( V - alpha + beta * R ) ];

end

