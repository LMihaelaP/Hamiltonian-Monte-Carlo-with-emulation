function [LogPrior,GradLogPrior] = Prior_Log_GradLog(param_sc, alp, bet, do_nuts)
%Compute log priors for the scaled parameters and their gradients

if do_nuts == 1
    param_sc = param_sc';
end

% for gamma prior
param = exp(param_sc);

LogPrior = sum ( -log(gamma(alp)) - alp .* log(bet) + alp .* param_sc - param./bet );

GradLogPrior = alp - param./bet;
GradLogPrior = GradLogPrior';
    
end

