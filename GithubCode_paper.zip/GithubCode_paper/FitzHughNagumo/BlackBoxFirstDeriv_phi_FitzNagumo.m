function FirstDeriv = BlackBoxFirstDeriv_phi_FitzNagumo(new_data, ...
    param_sc, time, tspan, nd, extra_p)

% Calculates the (simulator) derivative of the black-box FitzHugh-Nagumo w.r.t. every parameter 

% output: the first derivative for every parameter

V0 = extra_p(1);
R0 = extra_p(2);

FirstDeriv = NaN(nd, numel(new_data));

parfor i = 1:nd
    
    if i == 1
        h = 1e-3;
        param_sc_hplus = [param_sc(1)+h, param_sc(2:end)];
        param_sc_hminus = [param_sc(1)-h, param_sc(2:end)];
        
    elseif i == 2 
        h = 1e-3;
        param_sc_hplus = [param_sc(1), param_sc(2)+h, param_sc(3)];
        param_sc_hminus = [param_sc(1), param_sc(2)-h, param_sc(3)];
        
    else
        h = 1e-3;
        param_sc_hplus = [param_sc(1:2), param_sc(3)+h];   
        param_sc_hminus = [param_sc(1:2), param_sc(3)-h];   

    end

    param_hplus = exp(param_sc_hplus); 
    
    param_hminus = exp(param_sc_hminus);

    options = odeset('RelTol',1e-6,'AbsTol',1e-6);

    [~,new_data_hplus] = ode15s( @(t,y) SolveODEs_FitzHughNagumo(t, y, param_hplus(1:3)), time, [V0 R0], options );
    
    [~,new_data_hminus] = ode15s( @(t,y) SolveODEs_FitzHughNagumo(t, y, param_hminus(1:3)), time, [V0 R0], options );
     
    FirstDeriv(i,:) = (new_data_hplus(:) - new_data_hminus(:))./(2*h);
    
end


end