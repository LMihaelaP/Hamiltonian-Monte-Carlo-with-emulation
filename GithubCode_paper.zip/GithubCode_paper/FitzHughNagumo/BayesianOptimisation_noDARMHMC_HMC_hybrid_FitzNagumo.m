% Run DA-GP-RMHMC-HMC with Bayesian Optimisation for the number of leapfrog steps
% and the step size with application to the Fitz Nagumo problem
clear; close all;

% Add necesary paths, e.g. to GPstuff
GPpath = genpath('GPstuff-4.7');
addpath(GPpath); % add the folder and its subfolders to the search path
addpath('CommonFunctions');
addpath('Results')

nds = 10; % no of data sets

ntimeit = 3;% no of times we time the programme in the sampling phase

% Folder where the results will be saved
ResultsDestination = 'Results';

for ids = 1:nds
    
	% Load the workspace containing the initial + exploratory phase (run in the BayesianOptimisation_DAHMC_* script) and the optimum tuning parameters (run in BayesianOptimisation_noDARMHMC_*)
    load(sprintf('Results/BO_RMHMC_FindBestEpsL_FitzNagumo_dataset %d.mat', ids))	
    % eps and L for RMHMC
    L_hybrid(1) = bestL; % no of steps in generalised leapfrog scheme
    epsilon_hybrid(1) = bestEps; % step size
    
	% Load the workspace containing the initial + exploratory phase (run in the BayesianOptimisation_DAHMC_* script) and the optimum tuning parameters (run in BayesianOptimisation_DAHMC_* script)
    load(sprintf('Results/BO_HMC_FindBestEpsL_FitzNagumo_dataset %d.mat', ids))
    % eps and L for HMC
    L_hybrid(2) = bestL; % no of steps in leapfrog scheme
    epsilon_hybrid(2) = bestEps; % step size in leapfrog scheme
    
    %%
    % Now run RMHMC-HMC hybrid with the 'best' epsilon and L identified (3 times) for
    % every data set
    % Eps and L used are the same for DA and noDA and across different runs for
    % DA and noDA
    
    for it = 1:ntimeit
        
        do_DA = 0; % do not do delayed acceptance
        
        nSamples = 2000; % no of sampling phase samples
        nburnin = 500; % no of burnin phase samples
        
        phase_ind = 2; % phase index in Rasmussen's paper
        
        nrun = 20; % run 20 chains in parallel
        acc = zeros(nrun,1); % acceptance rate for every chain
        
        p_sample = cell(nrun,1); % parameter samples from the sampling phase
        s2_sample = cell(nrun,1); % sigma2 samples from the sampling phase
        ss_sample = cell(nrun,1); % sigma2 samples from the sampling phase
        
        noODE_counter_proc = zeros(nrun,1); % count no of ODE evaluations in the processing (sampling) phase
        
        delete(gcp('nocreate'))
        parpool('local', nrun)
        
        % Store cpu times for every run and average the at the end
        initime = NaN(nrun,1);
        fintime = NaN(nrun,1);
        
        p1 = Par(nd);
        
        noHMC_entries = zeros(nrun,1);

        % Run 10 chains in parallel from different initialisations and different
        % random seed generators
                
        parfor j=1:nrun
            
            noODE_counter_run = 0;
            
            % Initialise
            p0 = x_regr_refitted(end-j,:) .* sc; % original scale
            p_sample{j}(1,:) = log(p0); % unbounded
            
            ss_sample{j}(1,:) = Run_simulator_FitzNagumo(p0./sc, time, ...
                tspan, trueData, sc, extra_p);
            
            s2_sample{j}(1,:) = ss_sample{j}(1,:)./n;
            
            
            em_ind = 0; grad1_SimInd = 0; grad23_EmInd = [NaN NaN];
            [LogPosterior_sim, ~, ~, ~, ~, ss_sample{j}(1,:)] = ...
                HMCDerivPosterior_all_FitzNagumo(p_sample{j}(1,:), ...
                s2_sample{j}(1,:), trueData, ...
                time, tspan, alp, bet, nd, sc, extra_p, em_ind, phase_ind, grad1_SimInd, ...
                grad23_EmInd, gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
                mean_y, std_y, do_nuts, invLref);
            
            em_ind = 1; grad1_SimInd = NaN; grad23_EmInd = [1 1];
            [LogPosterior_em,GradLogPost_em, GradGradLogPost_em,...
                GradGradGradLogPost_em] = ...
                HMCDerivPosterior_all_FitzNagumo(p_sample{j}(1,:), ...
                s2_sample{j}(1,:), trueData, ...
                time, tspan, alp, bet, nd, sc, extra_p, em_ind, phase_ind, grad1_SimInd, ...
                grad23_EmInd, gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
                mean_y, std_y, do_nuts, invLref);
            
            % Enter loop to draw nSamples
            for i=2:nSamples+nburnin
                
                if i == nburnin + 1 % start measuring after the burnin
                    initime(j) = cputime;
                    Par.tic;
                end
                
                [p_sample{j}(i,:),LogPosterior_sim,LogPosterior_em,...
                    GradLogPost_em, GradGradLogPost_em, GradGradGradLogPost_em, ...
                    ss_sample{j}(i,:), no_counter_iter, noHMC_entries(j)] = ...
                    RMHMC_HMC_hybrid_FitzNagumo(p_sample{j}(i-1,:), s2_sample{j}(i-1,:), ...
                    epsilon_hybrid, ceil(rand*L_hybrid), gp_regr_refitted, x_regr_refitted, ...
                    y_regr_refitted, nd, phase_ind, trueData, time, ...
                    tspan, alp, bet, sc, extra_p, LogPosterior_sim, LogPosterior_em, ...
                    GradLogPost_em, GradGradLogPost_em,...
                    GradGradGradLogPost_em, ss_sample{j}(i-1,:), mean_y, ...
                    std_y, do_nuts, invLref, do_DA, NumOfNewtonSteps, noHMC_entries(j));
                
                if i > nburnin % start counting in the sampling phase
                    noODE_counter_run = noODE_counter_run + no_counter_iter;
                end
                
                if all(p_sample{j}(i,:) ~= p_sample{j}(i-1,:)) % we've just accepted the new point
                    acc(j) = acc(j) + 1;
                end
                
                if i<nburnin % sample sigma2 in sampling phase
                    s2_sample{j}(i,:) = s2_sample{j}(i-1,:);
                else
                    s2_sample{j}(i,:) = 1./gamrnd(a+0.5*n, 1./(b+0.5*ss_sample{j}(i,:)));
                end
                
            end
            
            noODE_counter_proc(j) = noODE_counter_proc(j) + noODE_counter_run;
            
            p1(j) = Par.toc;
            
            fintime(j) = cputime;
        end
        
        CPUtime_BO_noDAGPRMHMC_HMC_hybrid_sampling = fintime-initime;
        
        ElapsedTime_BO_noDAGPRMHMC_HMC_hybrid_sampling = NaN(nd,1);
        
        for j=1:nrun
            ElapsedTime_BO_noDAGPRMHMC_HMC_hybrid_sampling(j) = p1(1,j).ItStop - p1(1,j).ItStart;
        end
        
        fname = sprintf('FitzNagumo_dataset %d_BO_noDAGPRMHMC_HMC_hybrid_sampling %d.mat', ids, it);
        matfile = fullfile(ResultsDestination,fname);
        save(matfile)
        
    end % ntimeit
    
end % nds

exit;