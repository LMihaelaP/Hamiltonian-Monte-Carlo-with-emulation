This folder contains the Matlab scripts to run Hamiltonian/Lagrangian Monte Carlo algorithms for the FitzHugh-Nagumo model.

- Synthetic data generation, as well as initial and exploration for GPHMC and sampling phase for the DA-GP-HMC: BayesianOptimisation_DAHMC_FitzNagumo.m (this should be run first)

- Sampling phase with noDA-GP-HMC (with optimisation of tuning parameters performed in DA-GP-HMC): BayesianOptimisation_noDAHMC_FitzNagumo.m

- Sampling phase with noDA-GP-RMHMC (with Bayesian Optimisation for optimisation of tuning parameters): BayesianOptimisation_noDARMHMC_FitzNagumo.m (this should be run before the DA-GP-RMHMC-HMC_hybrid or noDA-GP-RMHMC-HMC_hybrid to obtain the optimum RMHMC tuning parameters)

- Sampling phase with DA-GP-RMHMC-HMC_hybrid (with optimisation of tuning parameters performed in noDA-GP-RMHMC): BayesianOptimisation_DARMHMC_HMC_hybrid_FitzNagumo.m

- Sampling phase with noDA-GP-RMHMC-HMC_hybrid (with optimisation of tuning parameters performed in noDA-GP-RMHMC): BayesianOptimisation_noDARMHMC_HMC_hybrid_FitzNagumo.m

- Sampling phase with noDA-GP-LDMC (with Bayesian Optimisation for optimisation of tuning parameters): BayesianOptimisation_noDALDMC_FitzNagumo.m (this should be run before the DA-GP-LDMC-HMC_hybrid or noDA-GP-LDMC-HMC_hybrid to obtain the optimum LDMC tuning parameters)

- Sampling phase with DA-GP-LDMC-HMC_hybrid (with optimisation of tuning parameters performed in noDA-GP-LDMC): BayesianOptimisation_DALDMC_HMC_hybrid_FitzNagumo.m

- Sampling phase with noDA-GP-LDMC-HMC_hybrid (with optimisation of tuning parameters performed in noDA-GP-LDMC): BayesianOptimisation_noDALDMC_HMC_hybrid_FitzNagumo.m
