function [ObjFct, Z, new_data] = Run_simulator_FitzNagumo(x, time, tspan, ...
    trueData, sc, extra_p)

% total number of time points = no of species * no of time points per species
ntp = size(trueData,1);

ns = size(trueData,2);

param = x .* sc;

V0 = extra_p(1);
R0 = extra_p(2);

n = size(x,1);

NLL = NaN(n,ns); Z = NaN(ntp,ns);

for i = 1:n
        
    try
        
        options = odeset('RelTol',1e-6,'AbsTol',1e-6);
        % unstable
        %         sol = ode15s( @(t,y) SolveODEs_FitzHughNagumo(t, y, param(i,1:3)), tspan, [V0 R0], options );
        %
        %         new_data = deval(sol, time); new_data = new_data';
        
        % stable
        [timedata,new_data] = ode15s( @(t,y) SolveODEs_FitzHughNagumo(t, y, param(i,1:3)), time, [V0 R0], options );
        
        for is=1:ns
            
            Z(:,is) = trueData(:,is) - new_data(:,is); % for all 2 species
            
            NLL(i,is) = sum(Z(:,is).^2); % for every species
            
        end
        
    catch
                
        new_data = NaN(size(trueData,1),size(trueData,2));
        
        for is=1:ns
              
            Z(:,is) = NaN(ntp,1);
            
            NLL(i, is) = 10^10/ns;
            
        end
        
    end % try
    
end

ObjFct = NLL;

end