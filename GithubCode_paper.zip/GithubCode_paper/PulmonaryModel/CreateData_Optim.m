function state = CreateData_Optim(id)

% Extract data from output files

pu1 = load(sprintf('pu1_C_%d.2d', id)); % id is for every simulation run  

[~,~,p,q,~,~] = gnuplot(pu1);

pressure = p(:,1); flow = q(:,floor(end/2));

state = [flow; pressure];

end