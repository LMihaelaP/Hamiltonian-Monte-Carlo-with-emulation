% Run DA-GP-RMHMC with Bayesian Optimisation for the number of leapfrog steps
% and the step size with application to the pulmonary problem
clear; close all;

% Add necesary paths, e.g. to GPstuff
GPpath = genpath('GPstuff-4.7');
addpath(GPpath); % add the folder and its subfolders to the search path
addpath('CommonFunctions');
addpath('Results')

% Folder where the results will be saved
ResultsDestination = 'Results';

ntimeit = 3; % time the programme three times and take the best time

% Load data from the initial phase + exploratory phase (obtained from running Run_GPHMC_Exploratory_Pulm.m)
load('Results/PaperResults_GPHMC_Exploratory.mat')

id = 11; % id for data files
extra_p = [id, nd];

%% Sampling phase
% Now run (3 times) RMHMC with the 'best' epsilon and L identified by 
% running Run_BayesianOptimisation_noDARMHMC_Sampling_Pulm.m
% Eps and L used are the same for DA and noDA and across different runs for
% DA and noDA

load('Results/BO_RMHMC_FindBestEpsL_pulm.mat')

for it = 1:ntimeit
    
    do_DA = 1; % do delayed acceptance
    
    nSamples = 2000; % no of sampling phase samples
    nburnin = 100; % no of burnin phase samples
    L = bestL; % no of steps in leapfrog scheme
    epsilon = bestEps; % step size in leapfrog scheme
    phase_ind = 2; % phase index in Rasmussen's paper
    do_nuts = 0; % don't do nuts
    
    nrun = 10; % run 10 chains in parallel
    acc = zeros(nrun,1); % acceptance rate for every chain
    
    p_sample = cell(nrun,1); % parameter samples from the sampling phase
    s2_sample = cell(nrun,1); % sigma2 samples from the sampling phase
    ss_sample = cell(nrun,1); % sum-of-square samples from the sampling phase
    
    noPDE_counter_proc = zeros(nrun,1); % count no of PDE evaluations in the processing (sampling) phase
    
    % Initialise position vector
    for j = 1:nrun
        p0 = x_regr_refitted(end-40*j,:) .* sc; % original scale
        p_sample{j}(1,:) = log((p0-l)./(u-p0)); % unbounded
    end
    
    delete(gcp('nocreate'))
    parpool('local', nrun)
    
    parfor j = 1:nrun
        extra_p = [j+10, nd];
        
        par = (u.*exp(p_sample{j}(1,:))+l)./(1+exp(p_sample{j}(1,:)));
        
        [NLL, pass] = Run_simulator(par./sc, extra_p, ...
            truePressure, sc, gp_ind, corrErr);
        
        ss_sample{j}(1) = NLL;
        
        if pass == 1
            s2_sample{j}(1) = ss_sample{j}(1)/(n-nd);
        else
            disp('Choose different starting values for the parameters')
        end
    end
    
    % Store cpu times for every run and average the at the end
    initime = NaN(nrun,1);
    fintime = NaN(nrun,1);
    
    p1 = Par(nd);
    
    % Run 10 chains in parallel from different initialisations and different
    % random seed generators
    
    parfor j = 1:nrun
        
        noPDE_counter_run = 0;
        
        extra_p = [j+10, nd];
        
        em_ind = 0; % use simulator for beginning of trajectory
        grad1_SimInd = 0; grad23_EmInd = [NaN NaN];
        LogPosterior_sim = ...
            HMCDerivPosterior_all_MoreEfficient_Generic_CorrectedImproved(p_sample{j}(1,:), ...
            s2_sample{j}(1), truePressure, alp, bet, GP_hyperHyper,...
            extra_p, l, u, sc, em_ind, phase_ind, grad1_SimInd, ...
            grad23_EmInd, gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
            gp_class, x_class, y_class, mean_y, std_y, do_nuts, corrErr, gp_ind, invLref);
                
        em_ind = 1;
        grad1_SimInd = NaN; grad23_EmInd = [1 1];
        [LogPosterior_em, GradLogPost_em, GradGradLogPost_em, ...
            GradGradGradLogPost_em] = ...
            HMCDerivPosterior_all_MoreEfficient_Generic_CorrectedImproved(p_sample{j}(1,:), ...
            s2_sample{j}(1), truePressure, alp, bet, GP_hyperHyper,...
            extra_p, l, u, sc, em_ind, phase_ind, grad1_SimInd, grad23_EmInd, ...
            gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
            gp_class, x_class, y_class, mean_y, std_y, do_nuts, corrErr, gp_ind, invLref);
        
        for i=2:nSamples+nburnin
            
            if i == nburnin + 1 % start measuring after the burnin
                initime(j) = cputime;
                Par.tic;
            end
            
            % for every i^th sample, run the trajectory
            
            [p_sample{j}(i,:),LogPosterior_sim,LogPosterior_em,GradLogPost_em,...
                GradGradLogPost_em, GradGradGradLogPost_em, ...
                ss_sample{j}(i), no_counter_iter] = ...
                RMHMC_pulm(p_sample{j}(i-1,:), s2_sample{j}(i-1), ...
                epsilon, ceil(rand*L), ...
                gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
                gp_class, x_class, y_class, nd, phase_ind, truePressure, ...
                alp, bet, extra_p, l, u, sc, LogPosterior_sim, ...
                LogPosterior_em, GradLogPost_em, GradGradLogPost_em, ...
                GradGradGradLogPost_em, ss_sample{j}(i-1), mean_y, std_y, ...
                do_nuts, corrErr, gp_ind, GP_hyperHyper, invLref, ...
                do_DA, NumOfNewtonSteps);
            
            if i > nburnin % start counting in the sampling phase
                noPDE_counter_run = noPDE_counter_run + no_counter_iter;
            end
            
            if all(p_sample{j}(i,:) ~= p_sample{j}(i-1,:)) % i.e. we've just accepted the new point
                acc(j) = acc(j) + 1;
            end
            
            if i<floor(nburnin/2) % sample sigma2 in sampling phase
                s2_sample{j}(i) = s2_sample{j}(i-1);
            else
                s2_sample{j}(i) = 1/gamrnd(a+0.5*n, 1/(b+0.5*ss_sample{j}(i)));
            end
            
        end
        
        noPDE_counter_proc(j) = noPDE_counter_proc(j) + noPDE_counter_run;
        
        p1(j) = Par.toc;
        
        fintime(j) = cputime;
        
    end % parfor
    
    CPUtime_BO_DAGPRMHMC_sampling = fintime-initime;
    
    ElapsedTime_BO_DAGPRMHMC_sampling = NaN(nd,1);
    
    for j=1:nrun
        ElapsedTime_BO_DAGPRMHMC_sampling(j) = p1(1,j).ItStop - p1(1,j).ItStart;
    end
    
    fname = sprintf('Pulm_BO_DAGPRMHMC_sampling %d.mat', it);
    matfile = fullfile(ResultsDestination,fname);
    save(matfile)
    
end % it=1:ntimeit

exit;