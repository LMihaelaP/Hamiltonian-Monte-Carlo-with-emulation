This folder contains the Matlab scripts to run Hamiltonian/Lagrangian Monte Carlo algorithms for the pulmonary model.

- Initial and exploration phase for the GPHMC: Run_GPHMC_Exploratory_Pulm (this should be run first)

- Sampling phase with DA-GP-HMC (with Bayesian Optimisation for optimisation of tuning parameters): Run_BayesianOptimisation_DAHMC_Sampling_Pulm.m (this should be run before the noDA-GP-HMC to obtain the optimum tuning parameters)

- Sampling phase with noDA-GP-HMC (with optimisation of tuning parameters performed in DA-GP-HMC): Run_BayesianOptimisation_noDAHMC_Sampling_Pulm.m

- Sampling phase with noDA-GP-RMHMC (with Bayesian Optimisation for optimisation of tuning parameters): Run_BayesianOptimisation_noDARMHMC_Sampling_Pulm.m (this should be run before the DA-GP-RMHMC to obtain the optimum tuning parameters)

- Sampling phase with DA-GP-RMHMC (with optimisation of tuning parameters performed in noDA-GP-RMHMC): Run_BayesianOptimisation_DARMHMC_Sampling_Pulm.m

- Sampling phase with noDA-GP-LDMC (with Bayesian Optimisation for optimisation of tuning parameters): Run_BayesianOptimisation_noDALDMC_Sampling_Pulm.m (this should be run before the DA-GP-LDMC to obtain the optimum tuning parameters)

- Sampling phase with DA-GP-LDMC (with optimisation of tuning parameters performed in noDA-GP-LDMC): Run_BayesianOptimisation_DALDMC_Sampling_Pulm.m

Additionally, the folder contains the real data sets:
- pC6_512.dat (blood pressure profile)
- qC6_512.dat (blood flow profile)