% Run DA-GP-NUTS for the pulmonary problem
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; close all

% Add necesary paths, e.g. to GPstuff
GPpath = genpath('GPstuff-4.7');
addpath(GPpath); % add the folder and its subfolders to the search path
addpath('CommonFunctions');
addpath('Results')

% Folder where the results will be saved
ResultsDestination = 'Results';

ntimeit = 3; % time the programme three times and take the best time

% Load data from the initial phase + exploratory phase (obtained from running Run_GPHMC_Exploratory_Pulm.m)
load('Results/PaperResults_GPHMC_Exploratory.mat')

id = 101; % id for data files
extra_p = [id, nd];

do_DA = 1; % do delayed acceptance

%% Sampling phase

phase_ind = 2; % phase index in Rasmussen's paper

do_nuts = 1; % do nuts

for it = 1:ntimeit
        
    % Set NUTS parameters
    delta = 0.8; % desired acc prob
    max_tree_depth = 10; % maximum depth of the tree in NUTS
    
    % The number of samples in the sampling phase
    nSamples = 2000; % no of samples in sampling phase
    nburnin = 100; % no of samples in burnin phase
    
    M = eye(nd); % mass matrix for momentum
    
    nrun = 10; % run 10 chains in parallel
    
    par_unbound_em = cell(nrun,1); % unbounded par samples from the sampling phase for the emulator
    logpost_unbound_em = cell(nrun,1); % log posterior evaluated at each par_unbound for the emulator
    gradlogpost_unbound_em = cell(nrun,1); % gradlogpost_unbound is gradient of emulated log posterior
    par_orig_sim = cell(nrun,1); % orig parameter samples from the sampling phase for the simulator
    s2_orig_sim = cell(nrun,1); % sigma2 samples from the sampling phase  for the simulator
    ss_orig_sim = cell(nrun,1); % sum-of-square samples from the sampling phase for the simulator
    logpost_orig_sim = cell(nrun,1); % log post evaluated at each par_orig using the simulator
    epsilon = cell(nrun,1); % list of epsilons along the mcmc for every chain
    acc = zeros(nrun,1); % acceptance rates for every chain
    
    % Run 10 chains in parallel from different initialisations and different
    % random seed generators
    delete(gcp('nocreate'))
    parpool('local', nrun)
    
    % Store cpu times for every run and average the at the end
    initime = NaN(nrun,1);
    fintime = NaN(nrun,1);
    
    noPDE_counter_proc = zeros(nrun,1); % count no of PDE evaluations in the processing (sampling) phase
    
    p1 = Par(nd);
    
    parfor j = 1:nrun
        
        noPDE_counter_run = 0;
        
        extra_p = [j+100, nd];
        
        p0 = x_regr_refitted(j,:) .* sc; % original scale
        p0 = log((p0-l)./(u-p0)); % unbounded
        p0 = p0';
        
        s2 = (y_regr_refitted(j)*std_y+mean_y)/n;
        
        em_ind=1; grad1_SimInd = NaN; grad23_EmInd = [0 0];
        f = @(p_unbound)HMCDerivPosterior_all_MoreEfficient_Generic_CorrectedImproved(p_unbound, ...
            s2, truePressure, alp, bet, GP_hyperHyper, extra_p, ...
            l, u, sc, em_ind, phase_ind, grad1_SimInd, grad23_EmInd, ...
            gp_regr_refitted, x_regr_refitted, y_regr_refitted, gp_class,...
            x_class, y_class, mean_y, std_y, do_nuts, corrErr, gp_ind, invLref);
        
        % Choose a reasonable first epsilon by a simple heuristic.
        em_ind=1; grad1_SimInd = NaN; grad23_EmInd = [0 0];
        [logp0, logpgrad0] = ...
            HMCDerivPosterior_all_MoreEfficient_Generic_CorrectedImproved(p0, s2, truePressure, ...
            alp, bet, GP_hyperHyper, extra_p, l, u, sc, em_ind, phase_ind, ...
            grad1_SimInd, grad23_EmInd, gp_regr_refitted, ...
            x_regr_refitted, y_regr_refitted, gp_class, x_class, ...
            y_class, mean_y, std_y, do_nuts, corrErr, gp_ind, invLref);
        
        [epsilon0, ~] = find_reasonable_epsilon(p0, logpgrad0, logp0, f);
        
        [par_unbound_em{j}(:,1), alpha_ave, nfevals_total, logpost_unbound_em{j}(1), ...
            gradlogpost_unbound_em{j}(:,1)] = NUTS(f, epsilon0, p0, logp0, logpgrad0, max_tree_depth);
        
        % Parameters for the dual averaging algorithm.
        gamma = 0.05; t0 = 10; kappa = 0.75;
        mu = log(10 * epsilon0); epsilonbar = 1; Hbar = 0;
        davg_par = [gamma, t0, kappa, mu, epsilonbar, Hbar];
        
        [epsilon{j}(1), Hbar, epsilonbar] = DualAveraging(1, delta, alpha_ave, davg_par);
        davg_par = [gamma, t0, kappa, mu, epsilonbar, Hbar]; % update param for dual avg
        
        par_orig_sim{j}(:,1) = (u'.*exp(par_unbound_em{j}(:,1))+l')./(1+exp(par_unbound_em{j}(:,1)));
        
        [NLL, pass] = Run_simulator(par_orig_sim{j}(:,1)'./sc, extra_p, truePressure, sc, gp_ind, corrErr);
        ss_orig_sim{j}(1) = NLL;
        if pass == 1
            s2_orig_sim{j}(1) = ss_orig_sim{j}(1)/n;
        else
            disp('Choose different starting values for the parameters')
        end
        
        em_ind = 0; % use simulator for beginning of trajectory
        grad1_SimInd = 0; grad23_EmInd = [NaN, NaN];
        logpost_orig_sim{j}(1) = ...
            HMCDerivPosterior_all_MoreEfficient_Generic_CorrectedImproved(par_unbound_em{j}(:,1), ...
            s2_orig_sim{j}(1), truePressure, alp, bet, GP_hyperHyper, extra_p, ...
            l, u, sc, em_ind, phase_ind, grad1_SimInd, grad23_EmInd, ...
            gp_regr_refitted, x_regr_refitted, y_regr_refitted, gp_class, ...
            x_class, y_class, mean_y, std_y, do_nuts, corrErr, gp_ind, invLref);
                
        em_ind = 1; % use emulator for beginning of trajectory
        grad1_SimInd = NaN; grad23_EmInd = [0 0];
        [logpost_unbound_em{j}(1), gradlogpost_unbound_em{j}(:,1)] = ...
            HMCDerivPosterior_all_MoreEfficient_Generic_CorrectedImproved(par_unbound_em{j}(:,1), ...
            s2_orig_sim{j}(1), truePressure, ...
            alp, bet, GP_hyperHyper, extra_p, l, u, sc, em_ind, phase_ind, ...
            grad1_SimInd, grad23_EmInd, ...
            gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
            gp_class, x_class, y_class, mean_y, std_y, do_nuts, corrErr, gp_ind, invLref);
        
        for i = 2:nSamples+nburnin
            
            if i == nburnin + 1 % start measuring after the burnin
                initime(j) = cputime;
                Par.tic;
            end
            
            % Redefine f for the newly drawn s2 to be used in the next NUTS iteration
            em_ind=1; grad1_SimInd = NaN; grad23_EmInd = [0 0];
            s2 = s2_orig_sim{j}(i-1);
            f = @(p_unbound)HMCDerivPosterior_all_MoreEfficient_Generic_CorrectedImproved(p_unbound,...
                s2, truePressure, alp, bet, GP_hyperHyper, extra_p, ...
                l, u, sc, em_ind, phase_ind, grad1_SimInd, grad23_EmInd, ...
                gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
                gp_class, x_class, y_class, mean_y, std_y, do_nuts, corrErr, gp_ind, invLref);
            
            if i > floor(nburnin/2)
                % Adjust the logpost and its gradient for the newly drawn s2 ~ IG
                [newlogpost_unbound, newgradlogpost_unbound] = f(par_unbound_em{j}(:,i-1));
                
                LogPosterior_sim_begin = -n/2*log(s2)-n/2*log(2*pi) - ...
                    ss_orig_sim{j}(i-1)/(2*s2) + ...
                    Prior_Log_GradLog(par_unbound_em{j}(:,i-1), alp, bet, do_nuts);
                
                LogPosterior_em_begin = newlogpost_unbound;
                
            else
                
                newlogpost_unbound = logpost_unbound_em{j}(i-1);
                newgradlogpost_unbound = gradlogpost_unbound_em{j}(:,i-1);
                
                LogPosterior_sim_begin = logpost_orig_sim{j}(i-1);
                LogPosterior_em_begin = logpost_unbound_em{j}(i-1);
                
            end
            
            [par_unbound_em{j}(:,i), alpha_ave, nfevals, logpost_unbound_em{j}(i), ...
                gradlogpost_unbound_em{j}(:,i)] = NUTS(f, epsilon{j}(i-1), par_unbound_em{j}(:,i-1), ...
                newlogpost_unbound, newgradlogpost_unbound, max_tree_depth);
            
            % Adapt epsilon using dual average algorithm for par_unbound_em(:,i)
            % regardless of whether we have accepted or not
            if i <= nburnin % we adapt epsilon within the burnin phase
                
                [epsilon{j}(i), Hbar, epsilonbar] = DualAveraging(i, delta, alpha_ave, davg_par);
                davg_par = [gamma, t0, kappa, mu, epsilonbar, Hbar]; % update param for dual avg
            else
                
                epsilon{j}(i) = epsilonbar; % use last adapted epsilonbar if we've stopped adapting
            end
            
            if all(par_unbound_em{j}(:,i) == par_unbound_em{j}(:,i-1)) % we've rejected
                %disp('reject in stage 1')
                par_orig_sim{j}(:,i) = par_orig_sim{j}(:,i-1);
                ss_orig_sim{j}(i) = ss_orig_sim{j}(i-1);
                logpost_orig_sim{j}(i) = logpost_orig_sim{j}(i-1);
                
            else
                
                %disp('accept in stage 1')
                % next calculate acc rate in stage 2 using the simulator in an MH step
                em_ind = 0;
                grad1_SimInd = 0; grad23_EmInd = [NaN NaN];
                [LogPosterior_sim_end, ~, ~, ~, ~, NLL_sim_end] = ...
                    HMCDerivPosterior_all_MoreEfficient_Generic_CorrectedImproved(par_unbound_em{j}(:,i), ...
                    s2_orig_sim{j}(i-1), ...
                    truePressure, alp, bet, GP_hyperHyper, extra_p, ...
                    l, u, sc, em_ind, phase_ind, grad1_SimInd, grad23_EmInd, ...
                    gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
                    gp_class, x_class, y_class, mean_y, std_y, ...
                    do_nuts, corrErr, gp_ind, invLref);
                
                if i > nburnin % start counting in the sampling phase
                    noPDE_counter_run = noPDE_counter_run + 1;
                end
                
                LogPosterior_em_end = logpost_unbound_em{j}(i);
                
                r2 = LogPosterior_sim_end - LogPosterior_sim_begin + ...
                    LogPosterior_em_begin - LogPosterior_em_end;
                
                if r2 > 0 || (r2 > log(rand)) % accept at 2nd stage
                    %disp('accept in stage 2')
                    acc(j) = acc(j) + 1;
                    
                    par_orig_sim{j}(:,i) = (u'.*exp(par_unbound_em{j}(:,i))+l')./(1+exp(par_unbound_em{j}(:,i)));
                    ss_orig_sim{j}(i) = NLL_sim_end;
                    logpost_orig_sim{j}(i) = LogPosterior_sim_end;
                    
                else % reject at 2nd stage
                    %disp('reject in stage 2')
                    par_orig_sim{j}(:,i) = par_orig_sim{j}(:,i-1);
                    par_unbound_em{j}(:,i) = par_unbound_em{j}(:,i-1);
                    ss_orig_sim{j}(i) = ss_orig_sim{j}(i-1);
                    logpost_orig_sim{j}(i) = logpost_orig_sim{j}(i-1);
                    logpost_unbound_em{j}(i) = logpost_unbound_em{j}(i-1); % update this to the old value if reject in 2
                    gradlogpost_unbound_em{j}(:,i) = gradlogpost_unbound_em{j}(:,i-1); % update this to the old value if reject in 2
                    
                end
                
            end
            
            if i <= floor(nburnin/2)
                s2_orig_sim{j}(i) = s2_orig_sim{j}(i-1);
            else
                % Update sigma2 in a Gibbs step in the sampling phase
                s2_orig_sim{j}(i) = 1/gamrnd(a+0.5*n, 1/(b+0.5*ss_orig_sim{j}(i)));
            end
            
        end
        
        noPDE_counter_proc(j) = noPDE_counter_proc(j) + noPDE_counter_run;
        
        p1(j) = Par.toc;
        
        fintime(j) = cputime;
        
    end % parfor
    
    CPUtime_DAGPNUTS_sampling = fintime-initime;
    
    ElapsedTime_DAGPNUTS_sampling = NaN(nd,1);
    
    for j=1:nrun
        ElapsedTime_DAGPNUTS_sampling(j) = p1(1,j).ItStop - p1(1,j).ItStart;
    end
    
    fname = sprintf('Pulm_DAGPNUTS_sampling %d.mat', it);
    matfile = fullfile(ResultsDestination,fname);
    save(matfile)
    
end % it=1:ntimeit

exit;