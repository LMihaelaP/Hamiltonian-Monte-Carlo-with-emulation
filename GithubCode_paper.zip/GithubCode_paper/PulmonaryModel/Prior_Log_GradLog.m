function [LogPrior,GradLogPrior] = Prior_Log_GradLog(param_sc, alp, bet, ...
    GP_hyperHyper, do_nuts, corrErr)

%Compute log priors for the scaled parameters and their gradients

if do_nuts == 1
    param_sc = param_sc';
end

expPar = exp(param_sc);

hd = length(GP_hyperHyper)/2; % 2 gp hyperparameters if correlated measurement errors assumed

if corrErr==0 % iid measurement errors
    
    % Compute log priors for the scaled parameters and their gradients
    LogPrior = sum( alp.*param_sc - (alp+bet).* log(1+expPar) - ...
        betaln(alp,bet) );
    
    % first derivative
    GradLogPrior = (alp - bet .* expPar)./(1+expPar) ;
    GradLogPrior = GradLogPrior';
    
else % correlated measurement errors
    
    LogPrior_bioPar = sum( alp.*param_sc(1:nbio) - (alp+bet).* log(1+expPar(1:nbio)) - ...
        betaln(alp,bet) );
    
    if em_ind == 1 || grad1_SimInd == 1
        GradLogPrior_bioPar = (alp - bet .* expPar(1:nbio))./(1+expPar(1:nbio)) ;
    end
    
    if gp_ind ~= 5
        LogPrior_GPhyperPar = - (log(sqrt(GP_hyperHyper(2))) + 0.5*log(2*pi)) - ...
            ((param_sc(end-1) - GP_hyperHyper(1))^2)/(2*GP_hyperHyper(2)) + ... %
            - (log(sqrt(GP_hyperHyper(4))) + 0.5*log(2*pi)) - ...
            ((param_sc(end) - GP_hyperHyper(3))^2)/(2*GP_hyperHyper(4));

        GradLogPrior_GPhyperPar = NaN(1,hd);
        
        GradLogPrior_GPhyperPar(1) =  - (param_sc(end-1) - GP_hyperHyper(1))/GP_hyperHyper(2);
        GradLogPrior_GPhyperPar(2) =  - (param_sc(end) - GP_hyperHyper(3))/GP_hyperHyper(4);
        
    else % gp_ind == 5
        
        LogPrior_GPhyperPar = log((1+expPar(end-1))/...
            ((GP_hyperHyper(2)*expPar(end-1)+GP_hyperHyper(1))*...
            (log(GP_hyperHyper(2))-log(GP_hyperHyper(1)))))+ ...
            log((expPar(end-1)*(GP_hyperHyper(2)-GP_hyperHyper(1)))/...
            (1+expPar(end-1))^2) + ... %
            log((1+expPar(end))/...
            ((GP_hyperHyper(4)*expPar(end)+GP_hyperHyper(3))*...
            (log(GP_hyperHyper(4))-log(GP_hyperHyper(3)))))+ ...
            log((expPar(end)*(GP_hyperHyper(4)-GP_hyperHyper(3)))/...
            (1+expPar(end))^2);% + ... %
        
        GradLogPrior_GPhyperPar = NaN(1,hd);
        
        GradLogPrior_GPhyperPar(1) = -expPar(end-1)/(1+expPar(end-1)) - ...
            (GP_hyperHyper(2)*expPar(end-1))/...
            (GP_hyperHyper(2)*expPar(end-1)+GP_hyperHyper(1)) + 1;
        
        GradLogPrior_GPhyperPar(2) = -expPar(end)/(1+expPar(end)) - ...
            (GP_hyperHyper(4)*expPar(end))/...
            (GP_hyperHyper(4)*expPar(end)+GP_hyperHyper(3)) + 1;
    end
    
    LogPrior = LogPrior_bioPar + LogPrior_GPhyperPar;
    
    GradLogPrior = [GradLogPrior_bioPar, GradLogPrior_GPhyperPar];
    GradLogPrior = GradLogPrior';
    
end

