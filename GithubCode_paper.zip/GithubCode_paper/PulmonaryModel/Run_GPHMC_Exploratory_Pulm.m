%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% GPHMC %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Runs GPHMC in exploratory phase %%%
%%% from paper by Rasmussen: Gaussian Processes to speed up
%%% Hybrid Monte Carlo for Expensive Bayesian Integrals
clear; close all;

% Add necesary paths, e.g. to GPstuff
GPpath = genpath('GPstuff-4.7');
addpath(GPpath); % add the folder and its subfolders to the search path
addpath('CommonFunctions');
addpath('Results')

% Folder where the results will be saved
ResultsDestination = 'Results';

%% Load the real data

trueFlow = importdata('qC6_512.dat');
truePressure = importdata('pC6_512.dat');


id = 100; % id for data files
nd = 4; % no of parameters
extra_p = [id, nd];
n = size(truePressure,1); % no of data points
do_nuts = 0; % we do HMC, not NUTS
corrErr = 0; % assume iid measurement errors
gp_ind = NaN; % not needed since iid errors assumed
GP_hyperHyper = NaN(6,1); % error correlation parameters (not needed since iid errors assumed)

% Bounds for original biophysical parameters
l = [7e04, -0.5, -0.5, -2.5];
u = [5e05, 1.92, 1.0, 1.5];

% Parameter scaling for emulation
sc = [10^6, 10, 10, 10];

%% Define prior (for original, unscaled parameters)
% Derived from rescaled beta distribution on the bounded parameters theta
% Be(1,1) = Uniform
alp = [1,1,1,1];
bet = [1,1,1,1];

%% Initial design phase of GPHMC algorithm: construct GP model
if 1
    initime = cputime;
    tic();
    X = sobolset(4, 'Skip',1.4e4,'Leap',0.15e14); % draw points from a Sobol sequence
    
    f3_vec = l(1) + (u(1)-l(1)) * X(:,1);
    rr1_vec = l(2) + (u(2)-l(2)) * X(:,2);
    rr2_vec = l(3) + (u(3)-l(3)) * X(:,3);
    cc1_vec = l(4) + (u(4)-l(4)) * X(:,4);
    
    x = [f3_vec, rr1_vec, rr2_vec, cc1_vec]./sc;
    
    noPDE_counter_InitExpl = 0; % count no of PDE evaluations in the initial & exploratory phase

    % Run simulator to obtain rss for training points
    [rss, pass] = Run_simulator(x, extra_p, truePressure, sc, gp_ind, corrErr);
    
    noPDE_counter_InitExpl = noPDE_counter_InitExpl + size(X,1);

    pass = logical(pass);
    
    x_class = x; y_class = 2.*pass-1; % only needed if a classifier is built (ignore for this paper)
    x_regr = x(pass,:); y_regr = rss(pass);
    
    %%%
    
    mean_y = mean(y_regr);
    std_y = std(y_regr);
    
    rss_max = max(max(rss(rss~=10^10)));
    rss_min = min(min(rss));
    
    y_regr = (y_regr-mean_y)./std_y; % mean 0 and std 1 of of y
    
    % Build GP model (rss emulator and classifier)
    X_r = sobolset(6, 'Skip',2e12,'Leap',0.9e15); % draw 10 values
    n_r = size(X_r, 1);
    
    l_r = [10  1  1  1  1  0.000000001];
    u_r = [10^7 60 60 60 60 1];
    
    % H_r matrix with magnsigma2, every lengthscale and likelihood noise variance on separate rows
    H_r = [l_r(1) + (u_r(1)-l_r(1)) * X_r(:,1), ...
        l_r(2) + (u_r(2)-l_r(2)) * X_r(:,2), ...
        l_r(3) + (u_r(3)-l_r(3)) * X_r(:,3), ...
        l_r(4) + (u_r(4)-l_r(4)) * X_r(:,4), ...
        l_r(5) + (u_r(5)-l_r(5)) * X_r(:,5), ...
        l_r(6) + (u_r(6)-l_r(6)) * X_r(:,6)];
    
    X_c = sobolset(5, 'Skip',4e8,'Leap',0.9e15); % draw 10 values
    n_c = size(X_c, 1);
    
    l_c = [1 1   0.1 0.5  1];
    u_c = [10 20   5   5  15];
    % H_c matrix with magnsigma2, every lengthscale and sigma2 on separate rows
    H_c = [l_c(1) + (u_c(1)-l_c(1)) * X_c(:,1), ...
        l_c(2) + (u_c(2)-l_c(2)) * X_c(:,2), ...
        l_c(3) + (u_c(3)-l_c(3)) * X_c(:,3), ...
        l_c(4) + (u_c(4)-l_c(4)) * X_c(:,4), ...
        l_c(5) + (u_c(5)-l_c(5)) * X_c(:,5)];
    
    [gp_regr, nlml_regr, gp_class, nlml_class] = ...
        GPmodel(x_regr, y_regr, x_class, y_class, H_r, [1 1 1 1 1]);
    
    [w,s] = gp_pak(gp_regr);
    disp(exp(w))
    
    [w,s] = gp_pak(gp_class);
    disp(exp(w))
    
    %Make predictions using gp_regr
    [E, Var] = gp_pred(gp_regr, x_regr, y_regr, x_regr);
    figure(1); clf(1); plot(y_regr, E, '.');
    hold on; plot(y_regr,y_regr,'-r')
    xlabel('Train data'); ylabel('Predictions')
    
    %% Exploratory phase of GPHMC algorithm
    
    phase_ind = 1; % phase index 1 (exploratory) in Rasmussen's algorithm
    
    do_DA = 1; % do delayed acceptance
    
    extraPar_gp = [mean_y, std_y];
    x_regr_refitted = x_regr;
    y_regr_refitted = y_regr;
    gp_regr_refitted = gp_regr;
    
    % Obtain the covariance matrix and find its inverse to pass on by reference
    % to the functions as to avoid the repeated matrix inversion
    [~,Cov] = gp_trcov(gp_regr_refitted, x_regr_refitted);
    L = chol(Cov,'lower');
    invL = L\eye(size(y_regr_refitted,1),size(y_regr_refitted,1)); % inverse of L
    % Cov = L'L; Cov^(-1) = (L'L)^(-1) = (L')^(-1)(L^(-1)) = (L^(-1))'(L^(-1))
    % (L')^(-1) = (L^(-1))', inverse of transpose is transpose of inverse for a triangular matrix
    invLref = largematrix; % create an object to pass the inverse of L as an argument by reference
    invLref.array = invL; 
        
    % Prior for the noise variance (IG with shape a and scale b)
    a = 0.001; b = 0.001; % uninformative

    sigma2 = 1.1; % fixed noise variance for now
    nSamples = 1000; % no of HMC samples
    L = 10; % no of steps in the leapfrog scheme
    epsilon = 0.003; % step size
    M = eye(nd); % mass matrix for momentum
    
    p = NaN(nSamples, nd); % parameter samples from the exploratory phase
    ss = NaN(nSamples, 1); % sum-of-square samples from the exploratory phase
    
    T_ss = quantile(y_regr_refitted.*std_y+mean_y, 0.0001); % threshold for RSS (delete points above this threshold)

    p(1,:) = x_regr(1,:) .* sc; % original scale
    
    em_ind = 0; % use simulator for beginning of trajectory
    NLL = mice_pulm_ss(p(1,:),truePressure,...
        gp_regr, x_regr, y_regr, ...
        gp_class, x_class, y_class, ...
        extraPar_gp, em_ind, phase_ind, extra_p, sc, gp_ind, corrErr);
    
    if NLL ~=10^10
        ss(1) = NLL;
    else
        disp('Choose different starting values for the parameters')
    end
    
    p(1,:) = log((p(1,:)-l)./(u-p(1,:))); % unbounded
    
    em_ind = 0; % use simulator for beginning of trajectory
    grad1_SimInd = 0; grad23_EmInd = [NaN, NaN];
    LogPosterior_sim = HMCDerivPosterior_all_MoreEfficient_Generic_CorrectedImproved(p(1,:), sigma2, ...
        truePressure, alp, bet, ...
        GP_hyperHyper,extra_p, l, u, sc, em_ind, phase_ind, ...
        grad1_SimInd, grad23_EmInd, ...
        gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
        gp_class, x_class, y_class, mean_y, std_y, do_nuts, corrErr, gp_ind, invLref);
    
    noPDE_counter_InitExpl = noPDE_counter_InitExpl + 1;

    em_ind = 1; % use simulator for beginning of trajectory
    grad1_SimInd = NaN; grad23_EmInd = [0 0];
    [LogPosterior_em, GradLogPost_em] = ...
        HMCDerivPosterior_all_MoreEfficient_Generic_CorrectedImproved(p(1,:), sigma2, ...
        truePressure, alp, bet, ...
        GP_hyperHyper,extra_p, l, u, sc, em_ind, phase_ind, ...
        grad1_SimInd, grad23_EmInd, ...
        gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
        gp_class, x_class, y_class, mean_y, std_y, do_nuts, corrErr, gp_ind, invLref);
    
    acc = 0; % acceptance rate
    
    j = 1;
    
    for k = 2:nSamples
        % for every i^th sample, run the trajectory
        %phase_ind = 1, so we run plain HMC, not DA HMC
        [p(k,:), LogPosterior_sim, LogPosterior_em, GradLogPost_em, ss(k), ...
            noPDE_counter_iter, gp_regr_refitted, x_regr_refitted, ...
            y_regr_refitted, mean_y, std_y,invLref] = ...
            HMC_pulm_MoreEfficient(p(k-1,:), sigma2, epsilon, L, ...
            gp_regr_refitted, x_regr_refitted, y_regr_refitted, ...
            gp_class, x_class, y_class, ...
            nd, phase_ind, truePressure, alp, bet, ...
            GP_hyperHyper, extra_p, l, u, sc, LogPosterior_sim, LogPosterior_em, ...
            GradLogPost_em, ss(k-1), mean_y, std_y, ...
            do_nuts, corrErr, gp_ind, M, invLref, do_DA);
        
        noPDE_counter_InitExpl = noPDE_counter_InitExpl + noPDE_counter_iter;
        
        % if new point accepted, at the end of every trajectory,
        % remove the j^th point and add the newly accepted point as a training
        % point in the GP, and re-fit the GP
        if all(p(k,:) ~= p(k-1,:)) % i.e. we've just accepted the new point
            acc = acc + 1;
            
            % starting from beginning, gradually remove the old [size(y_regr,1)] training
            % points whose rss > T_ss, as we accept new train points & refit GP
            if acc <= size(y_regr,1) % delete or skip when we've accepted
                if (y_regr_refitted(j) * std_y + mean_y) > T_ss
                    x_regr_refitted(j,:) = []; y_regr_refitted(j) = [];
                else
                    j = j + 1; % skip deleting
                end
            end
            
            param = (u.*exp(p(k,:))+l)./(1+exp(p(k,:))); % parameters on original scale
            param_em = param./sc; % parameters used in emulation
            
            if x_regr_refitted(end,:)~=param_em % i.e. if we haven't already
                % added this point as a consequence of sqrt(Var)>=3
                
                x_regr_refitted(end+1,:) = param_em;
                y_regr_refitted = y_regr_refitted .* std_y + mean_y; % bring on original scale
                y_regr_refitted(end+1) = ss(k); % because rss is on original scale
                
                mean_y = mean(y_regr_refitted);
                std_y = std(y_regr_refitted);
                y_regr_refitted = (y_regr_refitted - mean_y)./std_y;
                
                gp_regr_refitted = gp_optim(gp_regr_refitted,x_regr_refitted,y_regr_refitted);
                
                % Update cov matrix here to pass on by reference
                [~,Cov] = gp_trcov(gp_regr_refitted, x_regr_refitted);
                L = chol(Cov,'lower');
                invL = L\eye(size(y_regr_refitted,1),size(y_regr_refitted,1)); % inverse of L
                % Cov = L'L; Cov^(-1) = (L'L)^(-1) = (L')^(-1)(L^(-1)) = (L^(-1))'(L^(-1))
                % (L')^(-1) = (L^(-1))', inverse of transpose is transpose of inverse for a triangular matrix
                %invLref = largematrix; % create an object to pass the inverse of L as an argument by reference
                invLref.array = invL;
                
            end
            
        end
        
        if k>100
            sigma2 = 1./gamrnd(a+0.5*n, 1./(b+0.5*ss(k,:)));
        end
        
    end
    
    
    % Now discard some of the samples - burnin phase
    % (training points for the GP) for which sum-of-squares, ss
    % are above some threshold T_ss
    % this is to keep training points from high posterior probability regions
    
    y_regr_refitted = y_regr_refitted * std_y + mean_y;
    I_ss = find(y_regr_refitted < T_ss);
    y_regr_refitted = y_regr_refitted(I_ss);
    mean_y = mean(y_regr_refitted);
    std_y = std(y_regr_refitted);
    
    y_regr_refitted = (y_regr_refitted - mean_y)./std_y;
    x_regr_refitted = x_regr_refitted(I_ss,:);
    
    % Refit GP with burnin phase removed
    % Use this GP in the sampling phase
    gp_regr_refitted = gp_optim(gp_regr_refitted,x_regr_refitted,y_regr_refitted);
    
    % Update the covariance matrix and its inverse
    [~,Cov] = gp_trcov(gp_regr_refitted, x_regr_refitted);
    L = chol(Cov,'lower');
    invL = L\eye(size(y_regr_refitted,1),size(y_regr_refitted,1)); % inverse of L
    % Cov = L'L; Cov^(-1) = (L'L)^(-1) = (L')^(-1)(L^(-1)) = (L^(-1))'(L^(-1))
    % (L')^(-1) = (L^(-1))', inverse of transpose is transpose of inverse for a triangular matrix
    %invLref = largematrix; % create an object to pass the inverse of L as an argument by reference
    invLref.array = invL;
    
    fintime = cputime;
    elapsedtime = toc();
    
    time_preprocessing_GPHMC = fintime - initime;
    
    fname = 'PaperResults_GPHMC_Exploratory.mat';
    matfile = fullfile(ResultsDestination,fname);
    save(matfile)
        
end

exit;