function parsave2(fname, p_sample, LogLik, prior)
save(fname, 'p_sample', 'LogLik', 'prior')
end