classdef largematrix < handle   
  properties
      array
  end    
%   methods
%       function myfunc(obj)
%           obj.array=obj.array+1;
%       end
%   end    
end